java -jar getLatinTag.jar tr  "bayanlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlarin" 1000  keyword_tr.txt
