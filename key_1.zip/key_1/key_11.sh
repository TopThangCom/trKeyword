java -jar getLatinTag.jar tr  "bakıyon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıyordun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıyorsun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıyorsunuz" 1000  keyword_tr.txt
