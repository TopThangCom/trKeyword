java -jar getLatinTag.jar tr  "bahşişi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahşılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtimiza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtimizda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtiyar" 1000  keyword_tr.txt
