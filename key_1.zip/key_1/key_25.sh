java -jar getLatinTag.jar tr  "bakıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıpta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıra" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıray" 1000  keyword_tr.txt
