java -jar getLatinTag.jar tr  "bamini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamini.ttf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamland" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamse" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamsı" 1000  keyword_tr.txt
