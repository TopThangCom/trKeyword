java -jar getLatinTag.jar tr  "başkanlıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlıklarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanvekili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanvekilleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaptan" 1000  keyword_tr.txt
