java -jar getLatinTag.jar tr  "bakımından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımla" 1000  keyword_tr.txt
