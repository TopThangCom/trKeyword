java -jar getLatinTag.jar tr  "barında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındıramayanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındıran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındırdığı" 1000  keyword_tr.txt
