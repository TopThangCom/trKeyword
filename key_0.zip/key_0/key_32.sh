java -jar getLatinTag.jar tr  "baharatlık/baharat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlıklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharçiçek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahardar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahardin" 1000  keyword_tr.txt
