java -jar getLatinTag.jar tr  "bahaneler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahaneleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahanemdi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahanemdir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahanesiyle" 1000  keyword_tr.txt
