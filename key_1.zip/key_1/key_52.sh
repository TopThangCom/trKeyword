java -jar getLatinTag.jar tr  "bahçesi)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahcesinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesindeki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesinden" 1000  keyword_tr.txt
