java -jar getLatinTag.jar tr  "başarısında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısız." 1000  keyword_tr.txt
