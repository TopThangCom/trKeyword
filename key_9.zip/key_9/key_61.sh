java -jar getLatinTag.jar tr  "bayraqdaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraqdakı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrlalaa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrlla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrol" 1000  keyword_tr.txt
