java -jar getLatinTag.jar tr  "baltazar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balthazar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balthazard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balyajlı" 1000  keyword_tr.txt
