java -jar getLatinTag.jar tr  "bağlanmasıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmayacaksın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmaz" 1000  keyword_tr.txt
