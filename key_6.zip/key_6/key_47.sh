java -jar getLatinTag.jar tr  "başlatmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmıştır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlattı" 1000  keyword_tr.txt
