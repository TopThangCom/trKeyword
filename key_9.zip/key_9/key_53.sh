java -jar getLatinTag.jar tr  "bebeklerde.gaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerdeki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekleri" 1000  keyword_tr.txt
