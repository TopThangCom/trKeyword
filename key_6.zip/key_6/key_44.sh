java -jar getLatinTag.jar tr  "baslı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığı" 1000  keyword_tr.txt
