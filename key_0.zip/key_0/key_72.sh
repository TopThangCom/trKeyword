java -jar getLatinTag.jar tr  "bağlantıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantılara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantılarını" 1000  keyword_tr.txt
