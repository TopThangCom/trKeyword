java -jar getLatinTag.jar tr  "bayrağıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağımız" 1000  keyword_tr.txt
