java -jar getLatinTag.jar tr  "basınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınç-isı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncın" 1000  keyword_tr.txt
