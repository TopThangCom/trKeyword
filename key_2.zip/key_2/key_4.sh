java -jar getLatinTag.jar tr  "bakson" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteride" 1000  keyword_tr.txt
