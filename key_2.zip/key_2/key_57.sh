java -jar getLatinTag.jar tr  "bakkaldan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalköy" 1000  keyword_tr.txt
