java -jar getLatinTag.jar tr  "bağırmayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırov" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağım" 1000  keyword_tr.txt
