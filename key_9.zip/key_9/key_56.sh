java -jar getLatinTag.jar tr  "bazilikalar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilikas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilikası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilike" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baziliki" 1000  keyword_tr.txt
