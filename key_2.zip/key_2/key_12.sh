java -jar getLatinTag.jar tr  "balderas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldia" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldirlari" 1000  keyword_tr.txt
