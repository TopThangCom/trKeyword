java -jar getLatinTag.jar tr  "bayer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayeren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayern" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayernallee" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayernlb" 1000  keyword_tr.txt
