java -jar getLatinTag.jar tr  "baklavas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavasi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavasının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavaya" 1000  keyword_tr.txt
