java -jar getLatinTag.jar tr  "basilica" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basilika" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basilikum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basiller" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basim" 1000  keyword_tr.txt
