java -jar getLatinTag.jar tr  "bakıyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıyoruz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalbaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalbaşıoğlu" 1000  keyword_tr.txt
