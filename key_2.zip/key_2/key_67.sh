java -jar getLatinTag.jar tr  "bakmıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakoru" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakraç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakraçlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakre" 1000  keyword_tr.txt
