java -jar getLatinTag.jar tr  "balkonunu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balküpü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkuv" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ball" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balla" 1000  keyword_tr.txt
