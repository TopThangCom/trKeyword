java -jar getLatinTag.jar tr  "basarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarımızı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarımlar" 1000  keyword_tr.txt
