java -jar getLatinTag.jar tr  "bayardo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayarin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayarlalaa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatlama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatlamayan" 1000  keyword_tr.txt
