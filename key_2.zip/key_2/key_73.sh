java -jar getLatinTag.jar tr  "baksaydın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakşi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baksı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baksın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baksır" 1000  keyword_tr.txt
