java -jar getLatinTag.jar tr  "bakti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktiginda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktigini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktirmak" 1000  keyword_tr.txt
