java -jar getLatinTag.jar tr  "barajyolu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barakaldo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-akiva" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baraklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barakların" 1000  keyword_tr.txt
