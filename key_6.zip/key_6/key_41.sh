java -jar getLatinTag.jar tr  "başlattığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlattım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayabilmesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayabilseydim" 1000  keyword_tr.txt
