java -jar getLatinTag.jar tr  "batı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıağıl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıayaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıayrancı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıbay" 1000  keyword_tr.txt
