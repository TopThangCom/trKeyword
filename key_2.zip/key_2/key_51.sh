java -jar getLatinTag.jar tr  "balerina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balerini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balerinler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balerinlerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baleriny" 1000  keyword_tr.txt
