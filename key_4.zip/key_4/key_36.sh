java -jar getLatinTag.jar tr  "barışı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışında" 1000  keyword_tr.txt
