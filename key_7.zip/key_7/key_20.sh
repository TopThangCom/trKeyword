java -jar getLatinTag.jar tr  "başvurulamaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurular" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basvurulari" 1000  keyword_tr.txt
