java -jar getLatinTag.jar tr  "bangır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bangladeş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bangladeş'in" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ban-ı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banı" 1000  keyword_tr.txt
