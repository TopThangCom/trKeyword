java -jar getLatinTag.jar tr  "bağlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarsak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaşma" 1000  keyword_tr.txt
