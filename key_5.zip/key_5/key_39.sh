java -jar getLatinTag.jar tr  "başarslan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarsoft" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaşçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başasistan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başasistanlik" 1000  keyword_tr.txt
