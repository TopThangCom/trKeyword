java -jar getLatinTag.jar tr  "bazalar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazalt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazam" 1000  keyword_tr.txt
