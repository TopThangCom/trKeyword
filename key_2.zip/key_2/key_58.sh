java -jar getLatinTag.jar tr  "bakterisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterisine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteriyaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteriyel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteriyofaj" 1000  keyword_tr.txt
