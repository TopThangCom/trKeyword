java -jar getLatinTag.jar tr  "bahçeşehir-başakşehir/istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeşehirde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeşehir.koleji" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahcesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesi" 1000  keyword_tr.txt
