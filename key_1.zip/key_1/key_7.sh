java -jar getLatinTag.jar tr  "bakıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılabilecek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılabilecekse" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılacak" 1000  keyword_tr.txt
