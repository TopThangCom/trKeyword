java -jar getLatinTag.jar tr  "baktığımızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığınızda" 1000  keyword_tr.txt
