java -jar getLatinTag.jar tr  "batmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmazı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmış" 1000  keyword_tr.txt
