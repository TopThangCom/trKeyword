java -jar getLatinTag.jar tr  "başarısızdı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlığının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlık" 1000  keyword_tr.txt
