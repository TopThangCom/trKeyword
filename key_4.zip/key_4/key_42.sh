java -jar getLatinTag.jar tr  "barleben" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlett" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barleycorn" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barleyfield" 1000  keyword_tr.txt
