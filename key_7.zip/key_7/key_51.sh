java -jar getLatinTag.jar tr  "başlılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyor)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyorda" 1000  keyword_tr.txt
