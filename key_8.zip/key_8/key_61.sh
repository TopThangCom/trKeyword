java -jar getLatinTag.jar tr  "bayanım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bayanlar)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlar" 1000  keyword_tr.txt
