java -jar getLatinTag.jar tr  "bayramiç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramiç/çanakkale" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramidir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraminda" 1000  keyword_tr.txt
