java -jar getLatinTag.jar tr  "bağırsağın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsağını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bagırsak" 1000  keyword_tr.txt
