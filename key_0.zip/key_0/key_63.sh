java -jar getLatinTag.jar tr  "baharile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahariye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahariye'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahariyede" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharı" 1000  keyword_tr.txt
