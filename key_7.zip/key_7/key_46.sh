java -jar getLatinTag.jar tr  "başörtü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtülü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtülük" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtülüler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtülülere" 1000  keyword_tr.txt
