java -jar getLatinTag.jar tr  "basınında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başınıza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınköy" 1000  keyword_tr.txt
