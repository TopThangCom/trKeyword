java -jar getLatinTag.jar tr  "bakanligi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanliğin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanliklar" 1000  keyword_tr.txt
