java -jar getLatinTag.jar tr  "bankacılığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılığından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılığının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılıkta" 1000  keyword_tr.txt
