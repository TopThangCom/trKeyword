java -jar getLatinTag.jar tr  "balca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balcalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balcani" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçiçek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balcı" 1000  keyword_tr.txt
