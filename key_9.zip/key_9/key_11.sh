java -jar getLatinTag.jar tr  "bazz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazzar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazzi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazzi-" 1000  keyword_tr.txt
