java -jar getLatinTag.jar tr  "başüstüne" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başuzman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başuzmanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "#başv" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvur" 1000  keyword_tr.txt
