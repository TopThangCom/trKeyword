java -jar getLatinTag.jar tr  "başk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(b)aşka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(başka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b'aşk'a" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baş-ka" 1000  keyword_tr.txt
