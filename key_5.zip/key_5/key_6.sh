java -jar getLatinTag.jar tr  "başbilen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başboğa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baş-boyun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbuğ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbuğlar" 1000  keyword_tr.txt
