java -jar getLatinTag.jar tr  "başlangıcına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıcında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıcındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıcını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıçlar" 1000  keyword_tr.txt
