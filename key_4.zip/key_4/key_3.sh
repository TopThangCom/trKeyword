java -jar getLatinTag.jar tr  "barraza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barrel/day" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barreleye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barrier_size" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barrikadave" 1000  keyword_tr.txt
