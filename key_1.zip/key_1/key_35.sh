java -jar getLatinTag.jar tr  "bakimliolmak.com" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakim.parasi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimsiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimstore" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakinca" 1000  keyword_tr.txt
