java -jar getLatinTag.jar tr  "batması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmasıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmasından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmasını" 1000  keyword_tr.txt
