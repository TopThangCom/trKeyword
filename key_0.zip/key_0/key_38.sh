java -jar getLatinTag.jar tr  "bağlardı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarımın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağların" 1000  keyword_tr.txt
