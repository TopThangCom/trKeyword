java -jar getLatinTag.jar tr  "basımlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basımlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baş'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başın" 1000  keyword_tr.txt
