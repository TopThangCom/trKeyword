java -jar getLatinTag.jar tr  "baymaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baymavi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baymayın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baymec" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baymer" 1000  keyword_tr.txt
