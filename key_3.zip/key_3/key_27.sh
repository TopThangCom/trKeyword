java -jar getLatinTag.jar tr  "bantlaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlanir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlanır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlanmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlar" 1000  keyword_tr.txt
