java -jar getLatinTag.jar tr  "bakmama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmamıza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmasın" 1000  keyword_tr.txt
