java -jar getLatinTag.jar tr  "başnur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başoğlu'nun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başöğretmen" 1000  keyword_tr.txt
