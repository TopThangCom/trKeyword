java -jar getLatinTag.jar tr  "başkanımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanını" 1000  keyword_tr.txt
