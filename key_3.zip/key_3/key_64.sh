java -jar getLatinTag.jar tr  "bantlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlaşma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlık" 1000  keyword_tr.txt
