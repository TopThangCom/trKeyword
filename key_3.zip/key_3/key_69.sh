java -jar getLatinTag.jar tr  "barboza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbunu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbunyanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbuzano" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbz" 1000  keyword_tr.txt
