java -jar getLatinTag.jar tr  "barlan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlari" 1000  keyword_tr.txt
