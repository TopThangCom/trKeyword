java -jar getLatinTag.jar tr  "barsak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsaklarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsane" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsao" 1000  keyword_tr.txt
