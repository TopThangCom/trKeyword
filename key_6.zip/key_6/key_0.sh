java -jar getLatinTag.jar tr  "başkentidir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentimiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentini" 1000  keyword_tr.txt
