java -jar getLatinTag.jar tr  "başbakanının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanınızım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanları" 1000  keyword_tr.txt
