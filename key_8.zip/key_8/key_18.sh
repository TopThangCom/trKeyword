java -jar getLatinTag.jar tr  "baykus" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykuş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykuşa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykuşlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykuşu" 1000  keyword_tr.txt
