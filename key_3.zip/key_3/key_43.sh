java -jar getLatinTag.jar tr  "bankası-alaybey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-anadolu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-belediye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-cemalpaşa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası.com" 1000  keyword_tr.txt
