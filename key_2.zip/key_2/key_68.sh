java -jar getLatinTag.jar tr  "bakterii" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakteriler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterilerde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterilerdeki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterilerden" 1000  keyword_tr.txt
