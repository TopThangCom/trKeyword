java -jar getLatinTag.jar tr  "battık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battle." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battlebit" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battlecard" 1000  keyword_tr.txt
