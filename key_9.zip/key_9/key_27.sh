java -jar getLatinTag.jar tr  "bayramınızı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlarda" 1000  keyword_tr.txt
