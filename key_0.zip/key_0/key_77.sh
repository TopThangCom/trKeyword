java -jar getLatinTag.jar tr  "bağlanir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglanirken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanılamadı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanılamıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanılan" 1000  keyword_tr.txt
