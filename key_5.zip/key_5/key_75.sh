java -jar getLatinTag.jar tr  "basinda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basiniz" 1000  keyword_tr.txt
