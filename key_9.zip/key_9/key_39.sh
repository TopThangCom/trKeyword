java -jar getLatinTag.jar tr  "beceren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceride" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becerik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becerikli" 1000  keyword_tr.txt
