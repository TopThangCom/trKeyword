java -jar getLatinTag.jar tr  "basmaktadır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmalarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(basmalı)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmalı" 1000  keyword_tr.txt
