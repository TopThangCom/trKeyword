java -jar getLatinTag.jar tr  "başdenetçi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdenetçisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdoğan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(base)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "base)" 1000  keyword_tr.txt
