java -jar getLatinTag.jar tr  "batılın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıment" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batımer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batımı" 1000  keyword_tr.txt
