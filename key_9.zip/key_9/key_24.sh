java -jar getLatinTag.jar tr  "bebeğidir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebegimde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğime" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğimi" 1000  keyword_tr.txt
