java -jar getLatinTag.jar tr  "balkıca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkırı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkondan" 1000  keyword_tr.txt
