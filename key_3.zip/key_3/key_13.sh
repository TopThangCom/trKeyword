java -jar getLatinTag.jar tr  "balle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballebaazi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballerina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballerinas" 1000  keyword_tr.txt
