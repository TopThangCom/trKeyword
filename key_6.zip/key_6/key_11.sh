java -jar getLatinTag.jar tr  "başlamam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamamalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamaması" 1000  keyword_tr.txt
