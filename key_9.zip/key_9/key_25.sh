java -jar getLatinTag.jar tr  "bazari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazarke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazary" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazasız" 1000  keyword_tr.txt
