java -jar getLatinTag.jar tr  "başlamaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslamistir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamışlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamıştı" 1000  keyword_tr.txt
