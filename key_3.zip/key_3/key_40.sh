java -jar getLatinTag.jar tr  "barası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baratza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baraye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baraz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baraze" 1000  keyword_tr.txt
