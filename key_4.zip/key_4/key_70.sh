java -jar getLatinTag.jar tr  "barındırır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındırıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barındırmayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınılan" 1000  keyword_tr.txt
