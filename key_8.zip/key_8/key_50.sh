java -jar getLatinTag.jar tr  "bayi.ciceksepeti.com" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayide" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayiden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.e-gama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.hızlı" 1000  keyword_tr.txt
