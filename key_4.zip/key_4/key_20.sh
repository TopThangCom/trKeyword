java -jar getLatinTag.jar tr  "barkodun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodunu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkod-yazdirma-programi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barks" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barksdale" 1000  keyword_tr.txt
