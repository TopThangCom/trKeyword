java -jar getLatinTag.jar tr  "başrolünü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsağlığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsağlığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavciliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavcı" 1000  keyword_tr.txt
