java -jar getLatinTag.jar tr  "basiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıboş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıbozuk" 1000  keyword_tr.txt
