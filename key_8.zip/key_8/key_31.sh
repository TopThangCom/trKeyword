java -jar getLatinTag.jar tr  "bayanicgiyim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanicgiyim.com" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanifar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanı" 1000  keyword_tr.txt
