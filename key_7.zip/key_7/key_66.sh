java -jar getLatinTag.jar tr  "batıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıpark" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırabilirsin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıracağım" 1000  keyword_tr.txt
