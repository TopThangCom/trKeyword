java -jar getLatinTag.jar tr  "başkentliler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentlim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentray" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentte" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentten" 1000  keyword_tr.txt
