java -jar getLatinTag.jar tr  "başarılara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılarımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılarına" 1000  keyword_tr.txt
