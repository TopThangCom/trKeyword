java -jar getLatinTag.jar tr  "batmakla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmakta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmanda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmandaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmane" 1000  keyword_tr.txt
