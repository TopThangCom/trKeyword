java -jar getLatinTag.jar tr  "başmemuru" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmimar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmış" 1000  keyword_tr.txt
