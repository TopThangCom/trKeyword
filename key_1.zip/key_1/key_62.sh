java -jar getLatinTag.jar tr  "bakışmamız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıştan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıştığım" 1000  keyword_tr.txt
