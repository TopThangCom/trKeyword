java -jar getLatinTag.jar tr  "baharatçıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatın" 1000  keyword_tr.txt
