java -jar getLatinTag.jar tr  "bayraktaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktar)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktar'a" 1000  keyword_tr.txt
