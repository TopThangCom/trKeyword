java -jar getLatinTag.jar tr  "bağlica" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağliliğini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bagliyi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglı" 1000  keyword_tr.txt
