java -jar getLatinTag.jar tr  "başulu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başuluğ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başumi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başundaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başuni" 1000  keyword_tr.txt
