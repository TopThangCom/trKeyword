java -jar getLatinTag.jar tr  "barksız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkskin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkskins" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkyard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkzone" 1000  keyword_tr.txt
