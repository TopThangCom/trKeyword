java -jar getLatinTag.jar tr  "başkut" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslac" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basladi" 1000  keyword_tr.txt
