java -jar getLatinTag.jar tr  "bağlam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamaca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamadaki" 1000  keyword_tr.txt
