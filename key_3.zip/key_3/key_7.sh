java -jar getLatinTag.jar tr  "ballerine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballerini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballerup" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballerz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balleza" 1000  keyword_tr.txt
