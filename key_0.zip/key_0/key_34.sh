java -jar getLatinTag.jar tr  "bağlandığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandığınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandım" 1000  keyword_tr.txt
