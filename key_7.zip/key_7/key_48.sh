java -jar getLatinTag.jar tr  "bastırdı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırılan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırılması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırılmış" 1000  keyword_tr.txt
