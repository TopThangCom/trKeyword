java -jar getLatinTag.jar tr  "bahsetme" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsetmek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsetmem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsetti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsettiği" 1000  keyword_tr.txt
