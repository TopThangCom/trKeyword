java -jar getLatinTag.jar tr  "barışacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışçıl" 1000  keyword_tr.txt
