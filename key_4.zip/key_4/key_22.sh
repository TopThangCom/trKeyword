java -jar getLatinTag.jar tr  "basamağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağındaki" 1000  keyword_tr.txt
