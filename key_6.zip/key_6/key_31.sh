java -jar getLatinTag.jar tr  "basketballclub" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(basketbol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolcu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolcular" 1000  keyword_tr.txt
