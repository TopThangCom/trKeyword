java -jar getLatinTag.jar tr  "başer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başerdem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeser" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başesgioğlu" 1000  keyword_tr.txt
