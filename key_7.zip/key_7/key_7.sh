java -jar getLatinTag.jar tr  "batıni" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bâtınî" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıniler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bâtınîler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batınilerin" 1000  keyword_tr.txt
