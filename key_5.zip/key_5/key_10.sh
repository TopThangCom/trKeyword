java -jar getLatinTag.jar tr  "basitler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basitleştirilmiş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basitleştirin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basitlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basiyo" 1000  keyword_tr.txt
