java -jar getLatinTag.jar tr  "başrol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basrolde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başrolde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başroldeki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başroller" 1000  keyword_tr.txt
