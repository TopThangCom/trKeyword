java -jar getLatinTag.jar tr  "başkan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkana" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkandan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkan-giresunun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkani" 1000  keyword_tr.txt
