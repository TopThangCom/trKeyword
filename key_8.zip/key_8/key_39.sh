java -jar getLatinTag.jar tr  "bavulunda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavyera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxcalar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxışla" 1000  keyword_tr.txt
