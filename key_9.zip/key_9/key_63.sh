java -jar getLatinTag.jar tr  "bayramini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraminin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraminiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramı’’" 1000  keyword_tr.txt
