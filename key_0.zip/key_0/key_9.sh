java -jar getLatinTag.jar tr  "bağlantısını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısızlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısızlık" 1000  keyword_tr.txt
