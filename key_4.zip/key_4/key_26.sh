java -jar getLatinTag.jar tr  "basamaktadır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaktır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamıyorum" 1000  keyword_tr.txt
