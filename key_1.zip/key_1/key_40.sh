java -jar getLatinTag.jar tr  "bakimevi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimindan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimli" 1000  keyword_tr.txt
