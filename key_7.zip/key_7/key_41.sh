java -jar getLatinTag.jar tr  "baştacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştankara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başta-ortada-sonda" 1000  keyword_tr.txt
