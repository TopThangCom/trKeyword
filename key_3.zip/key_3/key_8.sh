java -jar getLatinTag.jar tr  "bandes" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandirma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandirmaspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandı" 1000  keyword_tr.txt
