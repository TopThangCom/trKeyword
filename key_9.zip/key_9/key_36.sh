java -jar getLatinTag.jar tr  "b.doğan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdrm" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdu.biz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.düzü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdüzü" 1000  keyword_tr.txt
