java -jar getLatinTag.jar tr  "'bahtiyâr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtiyardır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtiyarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtiyarın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baht-ı" 1000  keyword_tr.txt
