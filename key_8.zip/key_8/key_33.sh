java -jar getLatinTag.jar tr  "bayiniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.oktay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.olcayyapi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.ortak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayir" 1000  keyword_tr.txt
