java -jar getLatinTag.jar tr  "başkanlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskanlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlarına" 1000  keyword_tr.txt
