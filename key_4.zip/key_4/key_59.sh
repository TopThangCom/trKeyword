java -jar getLatinTag.jar tr  "barmy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barnemark" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barney" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barney's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barneys" 1000  keyword_tr.txt
