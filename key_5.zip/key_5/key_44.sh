java -jar getLatinTag.jar tr  "başeskioğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "base_url" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basev" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basf" 1000  keyword_tr.txt
