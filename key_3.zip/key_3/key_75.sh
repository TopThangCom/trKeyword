java -jar getLatinTag.jar tr  "baraf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajında" 1000  keyword_tr.txt
