java -jar getLatinTag.jar tr  "bas-aç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaçık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başak" 1000  keyword_tr.txt
