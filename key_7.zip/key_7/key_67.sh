java -jar getLatinTag.jar tr  "basurda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başurgan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basuriya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başürün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başusta" 1000  keyword_tr.txt
