java -jar getLatinTag.jar tr  "batıcılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batı'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıdaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıdamı" 1000  keyword_tr.txt
