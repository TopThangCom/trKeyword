java -jar getLatinTag.jar tr  "bayrakla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklarımız" 1000  keyword_tr.txt
