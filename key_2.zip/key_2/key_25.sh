java -jar getLatinTag.jar tr  "balkaymak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkiraz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkiz" 1000  keyword_tr.txt
