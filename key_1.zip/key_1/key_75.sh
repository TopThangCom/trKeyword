java -jar getLatinTag.jar tr  "bahçelievlerden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelievler/istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeli'nin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeli'ye" 1000  keyword_tr.txt
