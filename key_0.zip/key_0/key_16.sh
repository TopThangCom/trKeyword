java -jar getLatinTag.jar tr  "(bağkur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağ-kur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkur'" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağ-kur'a" 1000  keyword_tr.txt
