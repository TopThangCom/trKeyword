java -jar getLatinTag.jar tr  "bağırsakları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bagırsakların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsakların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsakta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsaktaki" 1000  keyword_tr.txt
