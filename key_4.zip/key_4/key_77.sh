java -jar getLatinTag.jar tr  "barikli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baril" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barilla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barillaro" 1000  keyword_tr.txt
