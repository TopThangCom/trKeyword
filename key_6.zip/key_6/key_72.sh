java -jar getLatinTag.jar tr  "başlatıcısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatıcısını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılamadı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılamaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılamıyor" 1000  keyword_tr.txt
