java -jar getLatinTag.jar tr  "bariyerlerde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyerleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyerli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barizah" 1000  keyword_tr.txt
