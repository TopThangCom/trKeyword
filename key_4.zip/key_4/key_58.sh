java -jar getLatinTag.jar tr  "bardaktir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaktır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardal" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardani" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardar" 1000  keyword_tr.txt
