java -jar getLatinTag.jar tr  "(bakmi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmissin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmışsın" 1000  keyword_tr.txt
