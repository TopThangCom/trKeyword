java -jar getLatinTag.jar tr  "başarabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarabiliriz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaracağım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaralı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basaramadim" 1000  keyword_tr.txt
