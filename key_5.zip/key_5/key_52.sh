java -jar getLatinTag.jar tr  "basinc" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinci" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basincli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinçli" 1000  keyword_tr.txt
