java -jar getLatinTag.jar tr  "bayramlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlarına" 1000  keyword_tr.txt
