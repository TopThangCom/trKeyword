java -jar getLatinTag.jar tr  "başlanması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanmıştır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarda" 1000  keyword_tr.txt
