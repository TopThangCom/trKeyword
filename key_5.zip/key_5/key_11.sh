java -jar getLatinTag.jar tr  "başatlığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başatlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başayaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başayran" 1000  keyword_tr.txt
