java -jar getLatinTag.jar tr  "batık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkaf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkent" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkent'te" 1000  keyword_tr.txt
