java -jar getLatinTag.jar tr  "baydiğin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bay.doktor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydoktor" 1000  keyword_tr.txt
