java -jar getLatinTag.jar tr  "barkli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkly" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkoddaki" 1000  keyword_tr.txt
