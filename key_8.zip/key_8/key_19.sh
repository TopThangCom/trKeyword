java -jar getLatinTag.jar tr  "bayan.cp.evlenmek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayane" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan_egosuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan.elbise" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan_hanfendi_kz" 1000  keyword_tr.txt
