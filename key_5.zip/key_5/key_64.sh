java -jar getLatinTag.jar tr  "başkaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalarından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalarını" 1000  keyword_tr.txt
