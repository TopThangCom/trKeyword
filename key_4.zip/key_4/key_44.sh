java -jar getLatinTag.jar tr  "barkçin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barked" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barker" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkey" 1000  keyword_tr.txt
