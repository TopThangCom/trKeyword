java -jar getLatinTag.jar tr  "barclaycard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barclays" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardabas" 1000  keyword_tr.txt
