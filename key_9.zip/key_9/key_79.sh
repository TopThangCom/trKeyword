java -jar getLatinTag.jar tr  "bebeleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebenin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebesiyiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebible" 1000  keyword_tr.txt
