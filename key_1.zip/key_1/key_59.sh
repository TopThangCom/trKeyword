java -jar getLatinTag.jar tr  "bahçeli'yi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçemde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçemdeki" 1000  keyword_tr.txt
