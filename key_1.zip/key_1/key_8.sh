java -jar getLatinTag.jar tr  "bahtlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baibü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bailar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baildi" 1000  keyword_tr.txt
