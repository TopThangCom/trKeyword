java -jar getLatinTag.jar tr  "bakmayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmayın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmazlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmazsan" 1000  keyword_tr.txt
