java -jar getLatinTag.jar tr  "başköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başköylü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskül" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskülde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskülü" 1000  keyword_tr.txt
