java -jar getLatinTag.jar tr  "bağlanti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantilari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantı" 1000  keyword_tr.txt
