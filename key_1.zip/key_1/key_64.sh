java -jar getLatinTag.jar tr  "bakanlığa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlıgı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığı)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığı-kolay" 1000  keyword_tr.txt
