java -jar getLatinTag.jar tr  "balcıgil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balcığından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçıkhisar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balcılar" 1000  keyword_tr.txt
