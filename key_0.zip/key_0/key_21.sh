java -jar getLatinTag.jar tr  "bahceci" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeci" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçecik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçecikli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçecikte" 1000  keyword_tr.txt
