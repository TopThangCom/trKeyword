java -jar getLatinTag.jar tr  "baskılara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılayanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılayıcı" 1000  keyword_tr.txt
