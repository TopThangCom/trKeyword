java -jar getLatinTag.jar tr  "batıklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıklarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıklığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıklık" 1000  keyword_tr.txt
