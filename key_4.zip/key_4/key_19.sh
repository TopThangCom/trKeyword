java -jar getLatinTag.jar tr  "bardarnas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardenas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardhyl" 1000  keyword_tr.txt
