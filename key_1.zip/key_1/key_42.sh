java -jar getLatinTag.jar tr  "bakacaksın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakaçlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakalavr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakalitler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakalitleri" 1000  keyword_tr.txt
