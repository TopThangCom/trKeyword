java -jar getLatinTag.jar tr  "baykuşun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykuşunun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baylan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baylar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayleaf" 1000  keyword_tr.txt
