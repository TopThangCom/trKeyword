java -jar getLatinTag.jar tr  "bakırköyden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırköy/istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırköyspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakış" 1000  keyword_tr.txt
