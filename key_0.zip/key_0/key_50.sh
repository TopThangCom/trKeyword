java -jar getLatinTag.jar tr  "bağlatan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlatma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlatmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayamam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayamamak" 1000  keyword_tr.txt
