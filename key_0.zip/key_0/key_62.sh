java -jar getLatinTag.jar tr  "bağışlanma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlanması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlanmazmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlasam" 1000  keyword_tr.txt
