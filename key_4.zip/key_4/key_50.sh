java -jar getLatinTag.jar tr  "barinma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barişi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barisic" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barisin" 1000  keyword_tr.txt
