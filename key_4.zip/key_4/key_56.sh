java -jar getLatinTag.jar tr  "bardaklarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklık" 1000  keyword_tr.txt
