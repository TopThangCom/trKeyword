java -jar getLatinTag.jar tr  "bebeğiniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğinize" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğinizin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebegın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bebek" 1000  keyword_tr.txt
