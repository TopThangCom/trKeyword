java -jar getLatinTag.jar tr  "başkasıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkatibi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkatibinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkatip" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkatsayı" 1000  keyword_tr.txt
