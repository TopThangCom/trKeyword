java -jar getLatinTag.jar tr  "baronları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baronların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baronu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baronun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barosunun" 1000  keyword_tr.txt
