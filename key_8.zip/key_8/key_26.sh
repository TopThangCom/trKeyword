java -jar getLatinTag.jar tr  "bayb" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baybağ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baybara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baybars" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baybaşin" 1000  keyword_tr.txt
