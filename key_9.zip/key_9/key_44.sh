java -jar getLatinTag.jar tr  "bebek.omleti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek-ortaköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekoski" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekoyunu" 1000  keyword_tr.txt
