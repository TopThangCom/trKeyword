java -jar getLatinTag.jar tr  "baştepe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başterziler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastirilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastiya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bast-ı" 1000  keyword_tr.txt
