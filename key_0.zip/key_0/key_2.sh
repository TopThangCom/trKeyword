java -jar getLatinTag.jar tr  "bağışlamanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlanabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlanamaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlandı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlanır" 1000  keyword_tr.txt
