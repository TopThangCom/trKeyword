java -jar getLatinTag.jar tr  "bastl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastlerglas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastles" 1000  keyword_tr.txt
