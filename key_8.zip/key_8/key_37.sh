java -jar getLatinTag.jar tr  "bayanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanmanavi.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan-ölgii" 1000  keyword_tr.txt
