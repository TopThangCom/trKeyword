java -jar getLatinTag.jar tr  "basamağından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklar" 1000  keyword_tr.txt
