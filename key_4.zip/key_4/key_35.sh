java -jar getLatinTag.jar tr  "bardaklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklardaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardakları" 1000  keyword_tr.txt
