java -jar getLatinTag.jar tr  "bebekleriniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekliğini" 1000  keyword_tr.txt
