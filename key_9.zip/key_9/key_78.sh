java -jar getLatinTag.jar tr  "baysallar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayşanslı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baysel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baysem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayside" 1000  keyword_tr.txt
