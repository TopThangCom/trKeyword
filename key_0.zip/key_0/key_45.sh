java -jar getLatinTag.jar tr  "bağlarçeşme" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlar'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglardi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlar/diyarbakır" 1000  keyword_tr.txt
