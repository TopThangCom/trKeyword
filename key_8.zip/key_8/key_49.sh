java -jar getLatinTag.jar tr  "bayatlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayatmı" 1000  keyword_tr.txt
