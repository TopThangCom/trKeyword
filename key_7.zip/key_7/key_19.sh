java -jar getLatinTag.jar tr  "başvurularında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurularının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basvurulur" 1000  keyword_tr.txt
