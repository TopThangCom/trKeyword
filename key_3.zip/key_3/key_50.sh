java -jar getLatinTag.jar tr  "barajı'nı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajlardaki" 1000  keyword_tr.txt
