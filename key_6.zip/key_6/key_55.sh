java -jar getLatinTag.jar tr  "başlayış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basligi" 1000  keyword_tr.txt
