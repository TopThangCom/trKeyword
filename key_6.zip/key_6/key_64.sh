java -jar getLatinTag.jar tr  "baskıall" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskı-balata" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıcılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıcılıkta" 1000  keyword_tr.txt
