java -jar getLatinTag.jar tr  "balmen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balmer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balmumcu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balmumu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balmumundan" 1000  keyword_tr.txt
