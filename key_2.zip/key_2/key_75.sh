java -jar getLatinTag.jar tr  "baklavacılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavacıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavacının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavacıoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavacısı" 1000  keyword_tr.txt
