java -jar getLatinTag.jar tr  "başkol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkomiser" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkomser" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkomutan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkomutanı" 1000  keyword_tr.txt
