java -jar getLatinTag.jar tr  "başbuğum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbuğ'un" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbuğuna" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçarkçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçarşı" 1000  keyword_tr.txt
