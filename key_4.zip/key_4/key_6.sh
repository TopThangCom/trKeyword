java -jar getLatinTag.jar tr  "bar(e)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bareke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bareme" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baremi" 1000  keyword_tr.txt
