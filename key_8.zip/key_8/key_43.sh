java -jar getLatinTag.jar tr  "bayii" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayiler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilerde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilere" 1000  keyword_tr.txt
