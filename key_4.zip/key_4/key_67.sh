java -jar getLatinTag.jar tr  "barınak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınaklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınakları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınarc" 1000  keyword_tr.txt
