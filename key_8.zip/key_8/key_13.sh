java -jar getLatinTag.jar tr  "bayiltma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayimiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayindir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayindirlik" 1000  keyword_tr.txt
