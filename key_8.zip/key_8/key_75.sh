java -jar getLatinTag.jar tr  "baycan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baycare" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baycu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayd" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydah" 1000  keyword_tr.txt
