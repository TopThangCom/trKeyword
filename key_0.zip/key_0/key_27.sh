java -jar getLatinTag.jar tr  "bağlılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlılığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlılığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlımı" 1000  keyword_tr.txt
