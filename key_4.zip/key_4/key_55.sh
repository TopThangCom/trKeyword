java -jar getLatinTag.jar tr  "başakşehir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakşehir'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakşehirde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakşehirden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakşehir'e" 1000  keyword_tr.txt
