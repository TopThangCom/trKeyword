java -jar getLatinTag.jar tr  "baktık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktıkça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktın" 1000  keyword_tr.txt
