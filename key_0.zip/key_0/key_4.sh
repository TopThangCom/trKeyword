java -jar getLatinTag.jar tr  "bağlaçlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaçlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaçlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaçları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaçların" 1000  keyword_tr.txt
