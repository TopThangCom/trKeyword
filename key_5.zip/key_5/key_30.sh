java -jar getLatinTag.jar tr  "basınsitesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıt" 1000  keyword_tr.txt
