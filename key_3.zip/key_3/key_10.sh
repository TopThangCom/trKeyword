java -jar getLatinTag.jar tr  "bantboru" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantdünyası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bant'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantın" 1000  keyword_tr.txt
