java -jar getLatinTag.jar tr  "barimt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barinaği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barinaklari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barinder" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barine" 1000  keyword_tr.txt
