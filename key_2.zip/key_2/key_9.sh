java -jar getLatinTag.jar tr  "balinese" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balirka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balişeyh" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baliyan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baliye" 1000  keyword_tr.txt
