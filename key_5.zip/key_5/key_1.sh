java -jar getLatinTag.jar tr  "başarili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarimli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarir" 1000  keyword_tr.txt
