java -jar getLatinTag.jar tr  "başlarsınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlasaydı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlasın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlata" 1000  keyword_tr.txt
