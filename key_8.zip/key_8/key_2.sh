java -jar getLatinTag.jar tr  "bayragimiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragimizdaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragimizin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragindaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağı" 1000  keyword_tr.txt
