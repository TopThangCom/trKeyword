java -jar getLatinTag.jar tr  "başkanlığı’nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığı-ümraniye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlıklar" 1000  keyword_tr.txt
