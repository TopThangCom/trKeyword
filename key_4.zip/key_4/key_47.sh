java -jar getLatinTag.jar tr  "barmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmanu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmaqlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmaqların" 1000  keyword_tr.txt
