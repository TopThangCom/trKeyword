java -jar getLatinTag.jar tr  "bayazhan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayazit" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayazitoglu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayazıt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayazıtoğlu" 1000  keyword_tr.txt
