java -jar getLatinTag.jar tr  "baziliky" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilio" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazillac" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazille" 1000  keyword_tr.txt
