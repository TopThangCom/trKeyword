java -jar getLatinTag.jar tr  "bakcell" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakcellde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakeriş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakicaz" 1000  keyword_tr.txt
