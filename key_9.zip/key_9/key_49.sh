java -jar getLatinTag.jar tr  "bazina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazinas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazinda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazines" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazinet" 1000  keyword_tr.txt
