java -jar getLatinTag.jar tr  "başaramadık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaramadım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaramadın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaramamanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaramazsam" 1000  keyword_tr.txt
