java -jar getLatinTag.jar tr  "başarıya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıyı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıyorum" 1000  keyword_tr.txt
