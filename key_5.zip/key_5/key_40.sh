java -jar getLatinTag.jar tr  "başka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkadem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskadir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskadır" 1000  keyword_tr.txt
