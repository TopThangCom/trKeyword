java -jar getLatinTag.jar tr  "battleye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavula" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavulla" 1000  keyword_tr.txt
