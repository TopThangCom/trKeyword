java -jar getLatinTag.jar tr  "bankasıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-fulya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-güzeloba" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-kanalköprü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-kumluca" 1000  keyword_tr.txt
