java -jar getLatinTag.jar tr  "baya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayad" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayadera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayadere" 1000  keyword_tr.txt
