java -jar getLatinTag.jar tr  "başpolisler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpolislerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpolislik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basra" 1000  keyword_tr.txt
