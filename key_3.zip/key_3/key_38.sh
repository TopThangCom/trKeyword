java -jar getLatinTag.jar tr  "balonlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balonlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balonlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balonları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balonlarım" 1000  keyword_tr.txt
