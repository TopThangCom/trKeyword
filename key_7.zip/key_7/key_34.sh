java -jar getLatinTag.jar tr  "başsavcısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bassaydın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başşehri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bassey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bassey-eyo" 1000  keyword_tr.txt
