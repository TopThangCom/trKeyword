java -jar getLatinTag.jar tr  "başlamaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamalıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamalıyım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamalıyız" 1000  keyword_tr.txt
