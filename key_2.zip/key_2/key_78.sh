java -jar getLatinTag.jar tr  "balkonlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonlu" 1000  keyword_tr.txt
