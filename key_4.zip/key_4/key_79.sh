java -jar getLatinTag.jar tr  "basamaklarındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarındandır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarının" 1000  keyword_tr.txt
