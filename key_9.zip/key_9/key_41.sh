java -jar getLatinTag.jar tr  "bebek.isimleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek-kandilli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerde" 1000  keyword_tr.txt
