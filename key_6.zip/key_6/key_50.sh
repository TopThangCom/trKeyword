java -jar getLatinTag.jar tr  "başlangıçları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıçlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıçta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıçtan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlangıçtır" 1000  keyword_tr.txt
