java -jar getLatinTag.jar tr  "bayım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayındır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayındır'a" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayındır'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayındır/izmir" 1000  keyword_tr.txt
