java -jar getLatinTag.jar tr  "balizza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıgı" 1000  keyword_tr.txt
