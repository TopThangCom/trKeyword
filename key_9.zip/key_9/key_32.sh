java -jar getLatinTag.jar tr  "becerikliyiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriksiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriksizim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriksizler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriksizler." 1000  keyword_tr.txt
