java -jar getLatinTag.jar tr  "başrahip" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basralı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basrî" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basrol" 1000  keyword_tr.txt
