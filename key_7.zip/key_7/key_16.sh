java -jar getLatinTag.jar tr  "başmısırlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmışsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmıştı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmıyoruz" 1000  keyword_tr.txt
