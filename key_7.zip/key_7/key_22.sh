java -jar getLatinTag.jar tr  "batığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıgöz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıgün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıhanlı" 1000  keyword_tr.txt
