java -jar getLatinTag.jar tr  "bblüv" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bbola" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b-boy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bboy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b-buzz" 1000  keyword_tr.txt
