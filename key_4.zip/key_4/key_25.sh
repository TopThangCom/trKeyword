java -jar getLatinTag.jar tr  "bartleys" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartuğ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barutçuoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barvy" 1000  keyword_tr.txt
