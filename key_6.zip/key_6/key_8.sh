java -jar getLatinTag.jar tr  "başlamasinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamasını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamasının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamasıyla" 1000  keyword_tr.txt
