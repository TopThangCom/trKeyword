java -jar getLatinTag.jar tr  "bakın)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bakınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakınız" 1000  keyword_tr.txt
