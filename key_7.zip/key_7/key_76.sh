java -jar getLatinTag.jar tr  "bastım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırabilirim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastıran" 1000  keyword_tr.txt
