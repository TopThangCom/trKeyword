java -jar getLatinTag.jar tr  "balıkçıköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçıl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçılığı" 1000  keyword_tr.txt
