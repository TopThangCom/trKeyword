java -jar getLatinTag.jar tr  "bağlayıcılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağli" 1000  keyword_tr.txt
