java -jar getLatinTag.jar tr  "bakilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakilmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakima" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakim.autoland" 1000  keyword_tr.txt
