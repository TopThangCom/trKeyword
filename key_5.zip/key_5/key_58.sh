java -jar getLatinTag.jar tr  "basarken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarmış" 1000  keyword_tr.txt
