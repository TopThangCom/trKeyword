java -jar getLatinTag.jar tr  "başiskele" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başiskele'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başiskele/kocaeli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basitçe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basit.cümle" 1000  keyword_tr.txt
