java -jar getLatinTag.jar tr  "bandırma-bursa-yenişehir-osmaneli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırma'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırmadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırma-izmir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırmalı" 1000  keyword_tr.txt
