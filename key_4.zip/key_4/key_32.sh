java -jar getLatinTag.jar tr  "barıştımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştırılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştırmak" 1000  keyword_tr.txt
