java -jar getLatinTag.jar tr  "bakışları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlarımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlarına" 1000  keyword_tr.txt
