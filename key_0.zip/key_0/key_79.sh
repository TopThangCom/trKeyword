java -jar getLatinTag.jar tr  "bağkur'a" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkura" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkurda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkur'dan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkurdan" 1000  keyword_tr.txt
