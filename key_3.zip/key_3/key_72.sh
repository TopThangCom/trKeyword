java -jar getLatinTag.jar tr  "banunun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banvari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banyoları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banyosunda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banyosunu" 1000  keyword_tr.txt
