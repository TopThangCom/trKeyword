java -jar getLatinTag.jar tr  "baslanir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanmalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanmalıdır" 1000  keyword_tr.txt
