java -jar getLatinTag.jar tr  "balkonsuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonunda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkonundan" 1000  keyword_tr.txt
