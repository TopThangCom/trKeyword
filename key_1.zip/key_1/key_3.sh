java -jar getLatinTag.jar tr  "bakırçay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırcılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırı" 1000  keyword_tr.txt
