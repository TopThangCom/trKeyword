java -jar getLatinTag.jar tr  "bartında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartınspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartle" 1000  keyword_tr.txt
