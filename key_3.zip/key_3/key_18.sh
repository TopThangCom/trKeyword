java -jar getLatinTag.jar tr  "balzamik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balzan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balzer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balzers" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balzi" 1000  keyword_tr.txt
