java -jar getLatinTag.jar tr  "barleymash" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barley's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barleys" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlin" 1000  keyword_tr.txt
