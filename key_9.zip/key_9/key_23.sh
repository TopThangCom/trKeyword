java -jar getLatinTag.jar tr  "bayramıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramı'na" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramı'nda" 1000  keyword_tr.txt
