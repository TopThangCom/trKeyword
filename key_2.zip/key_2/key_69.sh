java -jar getLatinTag.jar tr  "balkanoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkarli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkart" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkaş" 1000  keyword_tr.txt
