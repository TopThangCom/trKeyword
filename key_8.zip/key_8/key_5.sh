java -jar getLatinTag.jar tr  "baybayin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayberry" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baybo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayboğan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayburt" 1000  keyword_tr.txt
