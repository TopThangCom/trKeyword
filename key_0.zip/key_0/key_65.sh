java -jar getLatinTag.jar tr  "bağlanabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanabilirim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanamadı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanamadığımız" 1000  keyword_tr.txt
