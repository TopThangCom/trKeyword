java -jar getLatinTag.jar tr  "baydar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydarli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydarlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydemir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baydemirler" 1000  keyword_tr.txt
