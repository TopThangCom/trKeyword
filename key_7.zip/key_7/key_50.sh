java -jar getLatinTag.jar tr  "başöğretmenlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basogulları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başören" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basörtü" 1000  keyword_tr.txt
