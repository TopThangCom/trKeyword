java -jar getLatinTag.jar tr  "bataryaların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryasını" 1000  keyword_tr.txt
