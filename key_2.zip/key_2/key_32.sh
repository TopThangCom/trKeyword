java -jar getLatinTag.jar tr  "baktı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktığımız" 1000  keyword_tr.txt
