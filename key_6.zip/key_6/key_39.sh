java -jar getLatinTag.jar tr  "başlayalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayamam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayan" 1000  keyword_tr.txt
