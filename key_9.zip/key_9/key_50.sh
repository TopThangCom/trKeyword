java -jar getLatinTag.jar tr  "baziri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi-rind" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi.ru" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazis" 1000  keyword_tr.txt
