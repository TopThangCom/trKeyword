java -jar getLatinTag.jar tr  "baymera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayn" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baynazoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baynet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayoğlu" 1000  keyword_tr.txt
