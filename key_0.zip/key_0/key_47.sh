java -jar getLatinTag.jar tr  "bağlamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamaktansa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamam" 1000  keyword_tr.txt
