java -jar getLatinTag.jar tr  "baliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikçi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikçiliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikcilik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikçilik" 1000  keyword_tr.txt
