java -jar getLatinTag.jar tr  "bâtın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batınay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batınhan" 1000  keyword_tr.txt
