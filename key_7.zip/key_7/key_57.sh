java -jar getLatinTag.jar tr  "başpehlivanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpinar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpiskoposun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpınar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpolis" 1000  keyword_tr.txt
