java -jar getLatinTag.jar tr  "bahadın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahadır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahadırlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahadıroğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahalda" 1000  keyword_tr.txt
