java -jar getLatinTag.jar tr  "başarı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarı." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıcılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarı.com" 1000  keyword_tr.txt
