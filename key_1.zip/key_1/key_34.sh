java -jar getLatinTag.jar tr  "bahtımıza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtımızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtıyla" 1000  keyword_tr.txt
