java -jar getLatinTag.jar tr  "bayıltıcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıltılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıltır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıltma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıltmak" 1000  keyword_tr.txt
