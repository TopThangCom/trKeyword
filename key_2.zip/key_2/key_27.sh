java -jar getLatinTag.jar tr  "baklavada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavalari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavalik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavalik-yufkadan" 1000  keyword_tr.txt
