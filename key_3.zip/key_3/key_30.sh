java -jar getLatinTag.jar tr  "bankası-pozcu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-sanayi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankayla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bank/biz/saveetha/online" 1000  keyword_tr.txt
