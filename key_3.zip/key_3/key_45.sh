java -jar getLatinTag.jar tr  "barbaracle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbarlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbarları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbarosoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbarosun" 1000  keyword_tr.txt
