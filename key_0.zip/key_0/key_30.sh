java -jar getLatinTag.jar tr  "bağlanmandan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmasında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmasını" 1000  keyword_tr.txt
