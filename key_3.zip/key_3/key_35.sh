java -jar getLatinTag.jar tr  "banma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banrural" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bansari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantalmazas.hu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantalmazo" 1000  keyword_tr.txt
