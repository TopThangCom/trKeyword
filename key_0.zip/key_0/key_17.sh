java -jar getLatinTag.jar tr  "bağışlasın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlayabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağ.kap" 1000  keyword_tr.txt
