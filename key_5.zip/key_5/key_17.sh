java -jar getLatinTag.jar tr  "başekonomisti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baseler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baseley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baseline" 1000  keyword_tr.txt
