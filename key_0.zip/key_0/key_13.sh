java -jar getLatinTag.jar tr  "baharım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharın" 1000  keyword_tr.txt
