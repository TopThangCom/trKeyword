java -jar getLatinTag.jar tr  "baldöktü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldoyle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balduf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldur" 1000  keyword_tr.txt
