java -jar getLatinTag.jar tr  "balcıoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçova" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçovadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçova/izmir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balçova/narlıdere/izmir" 1000  keyword_tr.txt
