java -jar getLatinTag.jar tr  "bağlamaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglamanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamasına" 1000  keyword_tr.txt
