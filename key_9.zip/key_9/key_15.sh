java -jar getLatinTag.jar tr  "bayyıldız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaarke" 1000  keyword_tr.txt
