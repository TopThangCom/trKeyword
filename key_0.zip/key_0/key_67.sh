java -jar getLatinTag.jar tr  "bağlayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayici" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayıcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayıcıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlayıcılı" 1000  keyword_tr.txt
