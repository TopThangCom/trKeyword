java -jar getLatinTag.jar tr  "barline" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlinek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlume" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barm" 1000  keyword_tr.txt
