java -jar getLatinTag.jar tr  "bayraklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklı'dan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklı/izmir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraksız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakta" 1000  keyword_tr.txt
