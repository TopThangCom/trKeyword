java -jar getLatinTag.jar tr  "başbağ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbağlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakana" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakandı" 1000  keyword_tr.txt
