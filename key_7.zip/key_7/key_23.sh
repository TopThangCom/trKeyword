java -jar getLatinTag.jar tr  "baştok" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastonlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştuğ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastürk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştürk" 1000  keyword_tr.txt
