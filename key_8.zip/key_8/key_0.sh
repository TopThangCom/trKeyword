java -jar getLatinTag.jar tr  "batırın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırmak" 1000  keyword_tr.txt
