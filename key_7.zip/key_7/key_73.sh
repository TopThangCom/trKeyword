java -jar getLatinTag.jar tr  "başpare" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başparesiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başparmağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başparmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpehlivan" 1000  keyword_tr.txt
