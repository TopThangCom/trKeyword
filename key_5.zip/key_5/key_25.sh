java -jar getLatinTag.jar tr  "başarisini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarisiralamalari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarisiralamalari.com" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarisistemi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarisiz" 1000  keyword_tr.txt
