java -jar getLatinTag.jar tr  "barril" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barrland" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barrydale" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bars" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsa" 1000  keyword_tr.txt
