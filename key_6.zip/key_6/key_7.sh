java -jar getLatinTag.jar tr  "başkasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasının" 1000  keyword_tr.txt
