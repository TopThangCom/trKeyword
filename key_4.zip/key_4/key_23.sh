java -jar getLatinTag.jar tr  "bardagindan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağında" 1000  keyword_tr.txt
