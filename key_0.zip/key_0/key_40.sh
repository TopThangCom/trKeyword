java -jar getLatinTag.jar tr  "bağışçıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışçısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışıklama" 1000  keyword_tr.txt
