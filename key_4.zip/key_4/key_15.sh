java -jar getLatinTag.jar tr  "baristirma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariştirma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariye" 1000  keyword_tr.txt
