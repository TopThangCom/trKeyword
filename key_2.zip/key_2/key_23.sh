java -jar getLatinTag.jar tr  "balığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığıgiller" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığımın" 1000  keyword_tr.txt
