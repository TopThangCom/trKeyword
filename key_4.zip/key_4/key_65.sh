java -jar getLatinTag.jar tr  "baryum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barzani'ye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-zha" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(baş)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baş" 1000  keyword_tr.txt
