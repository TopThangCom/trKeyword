java -jar getLatinTag.jar tr  "başpehlivanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpehlivanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpehlivanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpehlivanlarımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başpehlivanların" 1000  keyword_tr.txt
