java -jar getLatinTag.jar tr  "bankalarınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarının" 1000  keyword_tr.txt
