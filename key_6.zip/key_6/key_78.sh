java -jar getLatinTag.jar tr  "başkumandan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkumandanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkurdistan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkurt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkurtlar" 1000  keyword_tr.txt
