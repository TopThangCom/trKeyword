java -jar getLatinTag.jar tr  "bayan.resmi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan_rmz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayansın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayansulu.kz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan.vn" 1000  keyword_tr.txt
