java -jar getLatinTag.jar tr  "başhemşire" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhemşirelik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhemşirenin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başika" 1000  keyword_tr.txt
