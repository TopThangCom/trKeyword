java -jar getLatinTag.jar tr  "bakiyeniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyenize" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyenizi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyesinden" 1000  keyword_tr.txt
