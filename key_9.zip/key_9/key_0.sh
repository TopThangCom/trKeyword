java -jar getLatinTag.jar tr  "bebekform" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekidz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekiki.ro" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek'in" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.irmigi" 1000  keyword_tr.txt
