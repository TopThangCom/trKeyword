java -jar getLatinTag.jar tr  "batıköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıl'" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılfayt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılı" 1000  keyword_tr.txt
