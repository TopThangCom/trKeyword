java -jar getLatinTag.jar tr  "balard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balarısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balart" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balasevic" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balası" 1000  keyword_tr.txt
