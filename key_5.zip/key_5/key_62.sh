java -jar getLatinTag.jar tr  "basima" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basimdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basimi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basimin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başina" 1000  keyword_tr.txt
