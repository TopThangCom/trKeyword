java -jar getLatinTag.jar tr  "balkanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlar-neresidir-balkan-ulkeleri-hangileridir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlıoğlu" 1000  keyword_tr.txt
