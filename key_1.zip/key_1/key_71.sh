java -jar getLatinTag.jar tr  "bahçıvan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçıvanım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçıvanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçıvanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçıvanlara" 1000  keyword_tr.txt
