java -jar getLatinTag.jar tr  "baharatları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlık" 1000  keyword_tr.txt
