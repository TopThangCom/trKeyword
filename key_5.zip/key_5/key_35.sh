java -jar getLatinTag.jar tr  "başımdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basımevi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımın" 1000  keyword_tr.txt
