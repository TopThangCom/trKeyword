java -jar getLatinTag.jar tr  "balatanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatasının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatçık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatkapı" 1000  keyword_tr.txt
