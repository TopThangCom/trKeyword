java -jar getLatinTag.jar tr  "bakisli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakislim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakişlim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakismamiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakişsiz" 1000  keyword_tr.txt
