java -jar getLatinTag.jar tr  "bebegimin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğimin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğimle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğimsin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğin" 1000  keyword_tr.txt
