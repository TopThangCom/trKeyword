java -jar getLatinTag.jar tr  "bağladık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladıktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladınız" 1000  keyword_tr.txt
