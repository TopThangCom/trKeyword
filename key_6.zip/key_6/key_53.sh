java -jar getLatinTag.jar tr  "başkale" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkale'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkale-dereiçi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaleli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalık" 1000  keyword_tr.txt
