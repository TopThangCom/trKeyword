java -jar getLatinTag.jar tr  "barniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barnizar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barnradio" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barnsley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barobirlik" 1000  keyword_tr.txt
