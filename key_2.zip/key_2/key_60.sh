java -jar getLatinTag.jar tr  "balığının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(balık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balık)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkavlayan" 1000  keyword_tr.txt
