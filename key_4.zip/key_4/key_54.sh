java -jar getLatinTag.jar tr  "barları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlaser" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlas'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlaz" 1000  keyword_tr.txt
