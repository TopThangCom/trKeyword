java -jar getLatinTag.jar tr  "baretsiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baribir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barigüi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bârik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barikade" 1000  keyword_tr.txt
