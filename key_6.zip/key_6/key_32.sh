java -jar getLatinTag.jar tr  "başlamadık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamakla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamaktadır" 1000  keyword_tr.txt
