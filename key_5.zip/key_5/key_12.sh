java -jar getLatinTag.jar tr  "başbakanlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanlığa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbalıkçı" 1000  keyword_tr.txt
