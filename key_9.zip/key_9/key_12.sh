java -jar getLatinTag.jar tr  "bebeğinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeginiz" 1000  keyword_tr.txt
