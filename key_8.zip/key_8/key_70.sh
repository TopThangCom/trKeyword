java -jar getLatinTag.jar tr  "bavulları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavulu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavulum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavulumu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bavuluna" 1000  keyword_tr.txt
