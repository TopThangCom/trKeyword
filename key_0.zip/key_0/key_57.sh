java -jar getLatinTag.jar tr  "bahar_yldz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bahçalarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçe" 1000  keyword_tr.txt
