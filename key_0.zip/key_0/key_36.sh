java -jar getLatinTag.jar tr  "bağlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıca'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlık" 1000  keyword_tr.txt
