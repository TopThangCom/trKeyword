java -jar getLatinTag.jar tr  "(baskılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskımanya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskın" 1000  keyword_tr.txt
