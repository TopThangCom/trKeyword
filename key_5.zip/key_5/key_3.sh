java -jar getLatinTag.jar tr  "başıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıldı" 1000  keyword_tr.txt
