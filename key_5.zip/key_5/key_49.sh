java -jar getLatinTag.jar tr  "başaramazsan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaraner" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaranlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaranoğlu" 1000  keyword_tr.txt
