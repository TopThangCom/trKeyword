java -jar getLatinTag.jar tr  "bağlantımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantınızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantınızı" 1000  keyword_tr.txt
