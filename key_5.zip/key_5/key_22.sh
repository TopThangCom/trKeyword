java -jar getLatinTag.jar tr  "başçarşıja" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçavuş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçavuşun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçayır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bas-çek" 1000  keyword_tr.txt
