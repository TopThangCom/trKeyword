java -jar getLatinTag.jar tr  "bayrama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramaly" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrambaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramdan" 1000  keyword_tr.txt
