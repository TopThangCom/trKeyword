java -jar getLatinTag.jar tr  "baktırmaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakuganları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakü’nün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakü-tiflis-kars" 1000  keyword_tr.txt
