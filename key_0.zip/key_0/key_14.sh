java -jar getLatinTag.jar tr  "bağışıklığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışıklığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışıklık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışıklıklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışın" 1000  keyword_tr.txt
