java -jar getLatinTag.jar tr  "bakis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakisiyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakislarina" 1000  keyword_tr.txt
