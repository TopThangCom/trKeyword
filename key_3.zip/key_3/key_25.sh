java -jar getLatinTag.jar tr  "ballabio" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballad" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balladą" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballade" 1000  keyword_tr.txt
