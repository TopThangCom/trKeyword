java -jar getLatinTag.jar tr  "banyosunun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barabelli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barabenka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baradine" 1000  keyword_tr.txt
