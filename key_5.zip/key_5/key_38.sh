java -jar getLatinTag.jar tr  "basıldığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıldığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıldığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıldıkça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılı" 1000  keyword_tr.txt
