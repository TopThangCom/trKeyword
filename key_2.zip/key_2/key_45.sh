java -jar getLatinTag.jar tr  "balımsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıq" 1000  keyword_tr.txt
