java -jar getLatinTag.jar tr  "banamı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bananazura" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banaozel.sahibinden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banarlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banarsi" 1000  keyword_tr.txt
