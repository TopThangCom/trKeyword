java -jar getLatinTag.jar tr  "bazen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazende" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazene" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazeni" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazge" 1000  keyword_tr.txt
