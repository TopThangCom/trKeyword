java -jar getLatinTag.jar tr  "bayık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıldı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıldım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılınca" 1000  keyword_tr.txt
