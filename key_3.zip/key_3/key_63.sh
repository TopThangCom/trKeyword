java -jar getLatinTag.jar tr  "barça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barcelona'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barcelonaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barcelona'yı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barcelonayı" 1000  keyword_tr.txt
