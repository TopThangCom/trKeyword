java -jar getLatinTag.jar tr  "bambaşka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamenda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bami" 1000  keyword_tr.txt
