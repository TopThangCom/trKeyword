java -jar getLatinTag.jar tr  "bazaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza+yatak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza-yatak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza+yatak+başlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazayı" 1000  keyword_tr.txt
