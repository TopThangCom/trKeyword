java -jar getLatinTag.jar tr  "banıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacilara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankaciligi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankaciliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacilik" 1000  keyword_tr.txt
