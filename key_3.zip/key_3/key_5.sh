java -jar getLatinTag.jar tr  "baltaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltasını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltayla" 1000  keyword_tr.txt
