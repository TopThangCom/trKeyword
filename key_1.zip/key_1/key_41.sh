java -jar getLatinTag.jar tr  "bahceli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeli/bor/niğde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeli'den" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahcelievler" 1000  keyword_tr.txt
