java -jar getLatinTag.jar tr  "baharlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlardaa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlari" 1000  keyword_tr.txt
