java -jar getLatinTag.jar tr  "başkatsayısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkavak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaydın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskenland" 1000  keyword_tr.txt
