java -jar getLatinTag.jar tr  "baldur's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baleks" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baleni" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balenli" 1000  keyword_tr.txt
