java -jar getLatinTag.jar tr  "bahcede" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçe'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçede" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçedeki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeden" 1000  keyword_tr.txt
