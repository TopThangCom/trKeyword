java -jar getLatinTag.jar tr  "bald" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldai" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldaki" 1000  keyword_tr.txt
