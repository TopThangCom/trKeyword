java -jar getLatinTag.jar tr  "bağlaçlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaçtan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağladığını" 1000  keyword_tr.txt
