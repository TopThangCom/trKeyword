java -jar getLatinTag.jar tr  "başarırsanız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarırsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarısistemi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısına" 1000  keyword_tr.txt
