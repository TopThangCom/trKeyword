java -jar getLatinTag.jar tr  "başvuruda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurudan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "//basvuru.kizilaykariyer.com/ilan/site.aspx" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulabilecek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurulacak" 1000  keyword_tr.txt
