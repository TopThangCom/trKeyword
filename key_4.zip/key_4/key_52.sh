java -jar getLatinTag.jar tr  "barmar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmarketim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmarkt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmbeker" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmen" 1000  keyword_tr.txt
