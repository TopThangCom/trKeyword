java -jar getLatinTag.jar tr  "başkanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanımıza" 1000  keyword_tr.txt
