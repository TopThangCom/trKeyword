java -jar getLatinTag.jar tr  "bakımlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımlarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımlısın" 1000  keyword_tr.txt
