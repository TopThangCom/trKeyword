java -jar getLatinTag.jar tr  "bardır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardoli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardon" 1000  keyword_tr.txt
