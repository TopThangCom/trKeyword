java -jar getLatinTag.jar tr  "baharları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlarımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharlık" 1000  keyword_tr.txt
