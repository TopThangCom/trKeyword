java -jar getLatinTag.jar tr  "barbey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbieler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-bier" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbiesozler" 1000  keyword_tr.txt
