java -jar getLatinTag.jar tr  "başvurmalıyız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurmuş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurmuşum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvursam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuru" 1000  keyword_tr.txt
