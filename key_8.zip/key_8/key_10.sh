java -jar getLatinTag.jar tr  "baygınlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayhorse" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.bati" 1000  keyword_tr.txt
