java -jar getLatinTag.jar tr  "başkara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkarakol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkarcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasindan" 1000  keyword_tr.txt
