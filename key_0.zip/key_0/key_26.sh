java -jar getLatinTag.jar tr  "bağlanma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmama" 1000  keyword_tr.txt
