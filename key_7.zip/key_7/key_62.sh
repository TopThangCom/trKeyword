java -jar getLatinTag.jar tr  "bataklıktaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batarken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryaları" 1000  keyword_tr.txt
