java -jar getLatinTag.jar tr  "basıncına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıncının" 1000  keyword_tr.txt
