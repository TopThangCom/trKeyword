java -jar getLatinTag.jar tr  "başıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımayım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımayım." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basımdan" 1000  keyword_tr.txt
