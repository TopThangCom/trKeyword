java -jar getLatinTag.jar tr  "bakalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakalımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakamazsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanım" 1000  keyword_tr.txt
