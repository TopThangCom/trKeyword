java -jar getLatinTag.jar tr  "başbakanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbakanından" 1000  keyword_tr.txt
