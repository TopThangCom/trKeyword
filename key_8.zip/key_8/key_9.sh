java -jar getLatinTag.jar tr  "bayol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayolente" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayollar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baypası" 1000  keyword_tr.txt
