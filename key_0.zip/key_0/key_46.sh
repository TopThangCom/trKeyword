java -jar getLatinTag.jar tr  "bağrı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrına" 1000  keyword_tr.txt
