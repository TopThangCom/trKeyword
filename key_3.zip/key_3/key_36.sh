java -jar getLatinTag.jar tr  "balmumunun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balmy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baloğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baloncuğu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baloncukları" 1000  keyword_tr.txt
