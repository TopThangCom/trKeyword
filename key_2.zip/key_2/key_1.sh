java -jar getLatinTag.jar tr  "balesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baleti" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baletki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baletleri" 1000  keyword_tr.txt
