java -jar getLatinTag.jar tr  "b-bind" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b&bir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b-bird" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b=bird" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b-biz" 1000  keyword_tr.txt
