java -jar getLatinTag.jar tr  "balıkta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıktaysan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkyolu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balım" 1000  keyword_tr.txt
