java -jar getLatinTag.jar tr  "başlığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlığının" 1000  keyword_tr.txt
