java -jar getLatinTag.jar tr  "bağışla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışladı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışladığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışlamak" 1000  keyword_tr.txt
