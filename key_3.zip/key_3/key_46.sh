java -jar getLatinTag.jar tr  "bankolari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankoları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankolu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankosuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banl" 1000  keyword_tr.txt
