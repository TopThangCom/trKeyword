java -jar getLatinTag.jar tr  "barıton" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bark" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkaby" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkada" 1000  keyword_tr.txt
