java -jar getLatinTag.jar tr  "baharsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar.skinclinic" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahartürk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharvatiya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar-yalanmış" 1000  keyword_tr.txt
