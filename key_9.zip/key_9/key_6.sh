java -jar getLatinTag.jar tr  "bebekoyunu.com.tr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekoyunu.com.trb" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeksi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeksiniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekte" 1000  keyword_tr.txt
