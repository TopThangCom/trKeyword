java -jar getLatinTag.jar tr  "bebek'teki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekteki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebektim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekule" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek_ümraniye" 1000  keyword_tr.txt
