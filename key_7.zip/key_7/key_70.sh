java -jar getLatinTag.jar tr  "başvuran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuranı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurdu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurduğu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurduğumuz" 1000  keyword_tr.txt
