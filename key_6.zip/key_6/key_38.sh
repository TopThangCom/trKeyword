java -jar getLatinTag.jar tr  "başlikli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslink" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basliyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başliyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basliyorum" 1000  keyword_tr.txt
