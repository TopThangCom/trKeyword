java -jar getLatinTag.jar tr  "bakışır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlardan" 1000  keyword_tr.txt
