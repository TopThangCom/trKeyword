java -jar getLatinTag.jar tr  "batımında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batımından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batımını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batımının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batın" 1000  keyword_tr.txt
