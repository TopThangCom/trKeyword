java -jar getLatinTag.jar tr  "bantmarketim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantvizyon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bant--yüz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banü" 1000  keyword_tr.txt
