java -jar getLatinTag.jar tr  "başlatır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatırım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatıyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslatma" 1000  keyword_tr.txt
