java -jar getLatinTag.jar tr  "bayadère" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanacademy.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayan.arkadaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanbuural" 1000  keyword_tr.txt
