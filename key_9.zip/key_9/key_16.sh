java -jar getLatinTag.jar tr  "baytarı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baytekin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayteks" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayülgen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayville" 1000  keyword_tr.txt
