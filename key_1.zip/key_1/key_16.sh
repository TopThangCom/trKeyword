java -jar getLatinTag.jar tr  "bakılan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılarak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıldığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıldığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılınca" 1000  keyword_tr.txt
