java -jar getLatinTag.jar tr  "bağlaç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlacından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlacını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlacının" 1000  keyword_tr.txt
