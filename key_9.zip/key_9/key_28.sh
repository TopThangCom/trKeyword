java -jar getLatinTag.jar tr  "bazlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlı.html" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazmi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazơ" 1000  keyword_tr.txt
