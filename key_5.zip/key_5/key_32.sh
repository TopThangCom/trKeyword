java -jar getLatinTag.jar tr  "başharık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhekim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhekimi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhekimliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhekimlik" 1000  keyword_tr.txt
