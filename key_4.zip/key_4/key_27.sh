java -jar getLatinTag.jar tr  "bartleby" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartleet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartlemy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartles" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bartley" 1000  keyword_tr.txt
