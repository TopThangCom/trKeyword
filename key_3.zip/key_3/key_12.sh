java -jar getLatinTag.jar tr  "ballu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballyvolane" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balm" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balme" 1000  keyword_tr.txt
