java -jar getLatinTag.jar tr  "bağırsak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsaklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsaklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsaklarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırsaklardan" 1000  keyword_tr.txt
