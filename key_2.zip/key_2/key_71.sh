java -jar getLatinTag.jar tr  "balikesir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikesirspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baliklari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baliklarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikli" 1000  keyword_tr.txt
