java -jar getLatinTag.jar tr  "bankalarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankamatiğe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankamızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankanız" 1000  keyword_tr.txt
