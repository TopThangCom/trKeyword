java -jar getLatinTag.jar tr  "battaniyeler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyeleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyeli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyelik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyesi" 1000  keyword_tr.txt
