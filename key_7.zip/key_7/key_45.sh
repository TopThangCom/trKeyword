java -jar getLatinTag.jar tr  "batıbeton" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıbeyi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıbirlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıçim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıcı" 1000  keyword_tr.txt
