java -jar getLatinTag.jar tr  "başgardiyan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgarson" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgedikler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgimpa" 1000  keyword_tr.txt
