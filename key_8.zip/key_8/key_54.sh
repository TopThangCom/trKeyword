java -jar getLatinTag.jar tr  "batıramaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıray" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırbaygil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırdı" 1000  keyword_tr.txt
