java -jar getLatinTag.jar tr  "bazaar-online.gr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaar.pk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaars" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaart" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaar.tf" 1000  keyword_tr.txt
