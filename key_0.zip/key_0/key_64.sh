java -jar getLatinTag.jar tr  "bağlıysa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağnaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağnazlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağri" 1000  keyword_tr.txt
