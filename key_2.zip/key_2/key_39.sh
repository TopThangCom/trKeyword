java -jar getLatinTag.jar tr  "balıkcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçığı" 1000  keyword_tr.txt
