java -jar getLatinTag.jar tr  "baharına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharıyım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharkozmetik" 1000  keyword_tr.txt
