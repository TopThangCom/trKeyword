java -jar getLatinTag.jar tr  "batı'dan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batı-doğu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıfren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batığa" 1000  keyword_tr.txt
