java -jar getLatinTag.jar tr  "bayliss" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baylık-tek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baylor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baymak" 1000  keyword_tr.txt
