java -jar getLatinTag.jar tr  "balade" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baladı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balaklava" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balança" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balanças" 1000  keyword_tr.txt
