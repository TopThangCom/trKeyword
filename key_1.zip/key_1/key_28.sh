java -jar getLatinTag.jar tr  "bahçe-garden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçekapı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçekent" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahcekoy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeköy" 1000  keyword_tr.txt
