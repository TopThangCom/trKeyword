java -jar getLatinTag.jar tr  "bazilarina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilika" 1000  keyword_tr.txt
