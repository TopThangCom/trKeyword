java -jar getLatinTag.jar tr  "bağlanılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanılıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglanır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanır" 1000  keyword_tr.txt
