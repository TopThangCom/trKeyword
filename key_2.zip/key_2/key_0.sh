java -jar getLatinTag.jar tr  "balance-board" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balanced" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balancelle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balancer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balanço" 1000  keyword_tr.txt
