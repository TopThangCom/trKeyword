java -jar getLatinTag.jar tr  "bakıcak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcılarının" 1000  keyword_tr.txt
