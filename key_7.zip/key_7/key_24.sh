java -jar getLatinTag.jar tr  "basmacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmacılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmacızade" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmadığınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmahalle" 1000  keyword_tr.txt
