java -jar getLatinTag.jar tr  "bakımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımında" 1000  keyword_tr.txt
