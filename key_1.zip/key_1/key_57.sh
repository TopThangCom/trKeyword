java -jar getLatinTag.jar tr  "bakımdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımektebleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımevi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımevi+ankara+alzheimer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımevleri" 1000  keyword_tr.txt
