java -jar getLatinTag.jar tr  "başaklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakpazar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakport" 1000  keyword_tr.txt
