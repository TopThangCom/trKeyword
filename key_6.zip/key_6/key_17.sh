java -jar getLatinTag.jar tr  "başkaldırıyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırmadıkça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskale" 1000  keyword_tr.txt
