java -jar getLatinTag.jar tr  "bahçemsin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçenin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesaray" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeşehir" 1000  keyword_tr.txt
