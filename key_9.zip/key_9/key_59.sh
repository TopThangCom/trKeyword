java -jar getLatinTag.jar tr  "bazar.bg" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazargan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazargani" 1000  keyword_tr.txt
