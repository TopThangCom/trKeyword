java -jar getLatinTag.jar tr  "başıydı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıyorlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıyorum" 1000  keyword_tr.txt
