java -jar getLatinTag.jar tr  "bağlanan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlananları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanarak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlandığı" 1000  keyword_tr.txt
