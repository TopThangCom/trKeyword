java -jar getLatinTag.jar tr  "başlayana" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayanındır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayanlara" 1000  keyword_tr.txt
