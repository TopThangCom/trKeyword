java -jar getLatinTag.jar tr  "barkına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkless" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkley's" 1000  keyword_tr.txt
