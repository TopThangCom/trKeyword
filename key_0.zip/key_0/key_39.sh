java -jar getLatinTag.jar tr  "bahardiorr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahardı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahardır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar.elmas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharevi" 1000  keyword_tr.txt
