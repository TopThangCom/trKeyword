java -jar getLatinTag.jar tr  "başlarız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslarsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarsa" 1000  keyword_tr.txt
