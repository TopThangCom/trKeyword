java -jar getLatinTag.jar tr  "basilar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basildilar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basildon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basili" 1000  keyword_tr.txt
