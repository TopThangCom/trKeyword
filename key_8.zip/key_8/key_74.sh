java -jar getLatinTag.jar tr  "bayernwerk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayerova" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayes" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayezid" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayezit" 1000  keyword_tr.txt
