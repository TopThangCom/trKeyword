java -jar getLatinTag.jar tr  "bddk'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdfutbol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bdö" 1000  keyword_tr.txt
