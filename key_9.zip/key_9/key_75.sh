java -jar getLatinTag.jar tr  "bazofil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazoskuamöz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazylika" 1000  keyword_tr.txt
