java -jar getLatinTag.jar tr  "bağlarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarken" 1000  keyword_tr.txt
