java -jar getLatinTag.jar tr  "bakici" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakicisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakidir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakilanlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiler" 1000  keyword_tr.txt
