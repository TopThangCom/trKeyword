java -jar getLatinTag.jar tr  "bazırı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazıyet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazkat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlama" 1000  keyword_tr.txt
