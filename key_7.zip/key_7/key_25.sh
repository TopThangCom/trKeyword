java -jar getLatinTag.jar tr  "batıkentte" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkentten" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkent/yenimahalle/ankara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıkhan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıklar" 1000  keyword_tr.txt
