java -jar getLatinTag.jar tr  "barsi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsmine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsys" 1000  keyword_tr.txt
