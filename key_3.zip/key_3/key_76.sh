java -jar getLatinTag.jar tr  "baraları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baralt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-ani.gif" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baranı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barankoğlu" 1000  keyword_tr.txt
