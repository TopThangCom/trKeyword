java -jar getLatinTag.jar tr  "başlatılırken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatınız." 1000  keyword_tr.txt
