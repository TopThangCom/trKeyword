java -jar getLatinTag.jar tr  "bakanlığı'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlıkça" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlıklar" 1000  keyword_tr.txt
