java -jar getLatinTag.jar tr  "basınevlerinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıni" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başının" 1000  keyword_tr.txt
