java -jar getLatinTag.jar tr  "bakmaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmali" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmalıyız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmam" 1000  keyword_tr.txt
