java -jar getLatinTag.jar tr  "basanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başantrenörü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarabilecek" 1000  keyword_tr.txt
