java -jar getLatinTag.jar tr  "bandında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandır" 1000  keyword_tr.txt
