java -jar getLatinTag.jar tr  "bayraktır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktutan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktutar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayram" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayram." 1000  keyword_tr.txt
