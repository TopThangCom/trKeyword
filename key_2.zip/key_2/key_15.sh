java -jar getLatinTag.jar tr  "baldırlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldızı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldızla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldo" 1000  keyword_tr.txt
