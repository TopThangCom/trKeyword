java -jar getLatinTag.jar tr  "bayramlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlaşalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlaşma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlaşması" 1000  keyword_tr.txt
