java -jar getLatinTag.jar tr  "bailey's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baileys" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bairiya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baiyoke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baıla" 1000  keyword_tr.txt
