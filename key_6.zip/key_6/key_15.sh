java -jar getLatinTag.jar tr  "başkomutanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkonsolos" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkonsolosluğu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkonsolosu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başköşe" 1000  keyword_tr.txt
