java -jar getLatinTag.jar tr  "bankası'ndan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankasından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası.net" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankasının" 1000  keyword_tr.txt
