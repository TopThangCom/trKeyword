java -jar getLatinTag.jar tr  "batılılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılıların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılılaşma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılılaşmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batılılaşması" 1000  keyword_tr.txt
