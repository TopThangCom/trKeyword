java -jar getLatinTag.jar tr  "başarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarırız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarırlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarırsan" 1000  keyword_tr.txt
