java -jar getLatinTag.jar tr  "barçin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barçino" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barcın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barçın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barclay" 1000  keyword_tr.txt
