java -jar getLatinTag.jar tr  "balyalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balyası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balyasının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balyoz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balza" 1000  keyword_tr.txt
