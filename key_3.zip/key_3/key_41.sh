java -jar getLatinTag.jar tr  "barbizon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbıe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbola" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barboy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barboyluk" 1000  keyword_tr.txt
