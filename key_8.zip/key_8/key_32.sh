java -jar getLatinTag.jar tr  "batıyakası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batı'yı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıyı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıyorsun" 1000  keyword_tr.txt
