java -jar getLatinTag.jar tr  "bazın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazır" 1000  keyword_tr.txt
