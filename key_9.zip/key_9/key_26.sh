java -jar getLatinTag.jar tr  "beatmedi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "be-be" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebecruz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeğe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeği" 1000  keyword_tr.txt
