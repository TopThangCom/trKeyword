java -jar getLatinTag.jar tr  "baskınlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıno.me" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskısına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskısında" 1000  keyword_tr.txt
