java -jar getLatinTag.jar tr  "balıkesirspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkhan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklar" 1000  keyword_tr.txt
