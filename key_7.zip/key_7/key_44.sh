java -jar getLatinTag.jar tr  "başörtülüydü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtüsü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başörtüsünü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başoyuncu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basoz" 1000  keyword_tr.txt
