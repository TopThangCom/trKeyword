java -jar getLatinTag.jar tr  "baziplanet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baziplanet.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baz.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazire" 1000  keyword_tr.txt
