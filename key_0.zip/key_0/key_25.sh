java -jar getLatinTag.jar tr  "bağlantıya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantıyı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlara(gule)" 1000  keyword_tr.txt
