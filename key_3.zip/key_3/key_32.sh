java -jar getLatinTag.jar tr  "ballımix" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıpınar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıstıx" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıyım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballpark" 1000  keyword_tr.txt
