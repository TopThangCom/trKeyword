java -jar getLatinTag.jar tr  "bakılmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bakım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımay" 1000  keyword_tr.txt
