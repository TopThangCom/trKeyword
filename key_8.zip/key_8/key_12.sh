java -jar getLatinTag.jar tr  "bayırı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayırkonak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayırköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayırları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykal" 1000  keyword_tr.txt
