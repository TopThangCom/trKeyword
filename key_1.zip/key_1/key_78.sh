java -jar getLatinTag.jar tr  "bakışı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışınla" 1000  keyword_tr.txt
