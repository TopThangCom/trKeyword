java -jar getLatinTag.jar tr  "bağrında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrışma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağrışmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağtepe" 1000  keyword_tr.txt
