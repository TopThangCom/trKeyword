java -jar getLatinTag.jar tr  "başmüfettişi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmüfettişlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmühendis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmühendisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmühendisliği" 1000  keyword_tr.txt
