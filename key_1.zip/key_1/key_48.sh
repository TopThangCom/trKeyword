java -jar getLatinTag.jar tr  "bahsedilen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsedilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsediliyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsedilmektedir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsedilmesi" 1000  keyword_tr.txt
