java -jar getLatinTag.jar tr  "bantlardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bantlarıyla" 1000  keyword_tr.txt
