java -jar getLatinTag.jar tr  "bahraın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahrde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahreyn" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahriye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahriyeli" 1000  keyword_tr.txt
