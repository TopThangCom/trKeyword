java -jar getLatinTag.jar tr  "balkaç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkanlardaki" 1000  keyword_tr.txt
