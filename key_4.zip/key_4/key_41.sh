java -jar getLatinTag.jar tr  "barışta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştepe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıştığını" 1000  keyword_tr.txt
