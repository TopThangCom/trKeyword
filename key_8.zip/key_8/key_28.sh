java -jar getLatinTag.jar tr  "bayraktar'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktarlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktaroğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktepe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraktir" 1000  keyword_tr.txt
