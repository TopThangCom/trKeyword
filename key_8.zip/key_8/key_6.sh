java -jar getLatinTag.jar tr  "bayrağa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayragim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağim" 1000  keyword_tr.txt
