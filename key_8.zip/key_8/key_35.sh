java -jar getLatinTag.jar tr  "bayis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayi.sembol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayisinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayı" 1000  keyword_tr.txt
