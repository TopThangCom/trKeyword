java -jar getLatinTag.jar tr  "bayileri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayiligi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayiliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayiliğini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilik" 1000  keyword_tr.txt
