java -jar getLatinTag.jar tr  "barkim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkın" 1000  keyword_tr.txt
