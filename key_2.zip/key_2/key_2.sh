java -jar getLatinTag.jar tr  "balıklıgöl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklıgöl'ün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklıova" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkselsu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıksırtı" 1000  keyword_tr.txt
