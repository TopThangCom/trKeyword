java -jar getLatinTag.jar tr  "bebidas" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebilon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebird" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebiş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebişim" 1000  keyword_tr.txt
