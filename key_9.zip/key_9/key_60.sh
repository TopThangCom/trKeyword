java -jar getLatinTag.jar tr  "bcdedit" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.cekmece" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.çekmece" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.çekmecede" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bcı" 1000  keyword_tr.txt
