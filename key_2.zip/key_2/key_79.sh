java -jar getLatinTag.jar tr  "balensiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balerin" 1000  keyword_tr.txt
