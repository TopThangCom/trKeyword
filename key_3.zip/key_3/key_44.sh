java -jar getLatinTag.jar tr  "balonlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balonlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balsalazide" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balsamı" 1000  keyword_tr.txt
