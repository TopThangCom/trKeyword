java -jar getLatinTag.jar tr  "balayında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balayını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balazs" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balbadem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balböceği" 1000  keyword_tr.txt
