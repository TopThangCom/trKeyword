java -jar getLatinTag.jar tr  "başsavcılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavcıları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavcıların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavcılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başsavcılık" 1000  keyword_tr.txt
