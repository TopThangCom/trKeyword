java -jar getLatinTag.jar tr  "baklagil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklagiller" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklagillerden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklagillerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklali" 1000  keyword_tr.txt
