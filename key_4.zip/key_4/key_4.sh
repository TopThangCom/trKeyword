java -jar getLatinTag.jar tr  "bareminerals" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baremleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barenboim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baresiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baretim" 1000  keyword_tr.txt
