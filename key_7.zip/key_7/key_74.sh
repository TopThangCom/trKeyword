java -jar getLatinTag.jar tr  "bassinet" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bassiri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bassklarinett" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basslayerz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basslı" 1000  keyword_tr.txt
