java -jar getLatinTag.jar tr  "batgirls" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batiad-bayrampaşa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bati-hukukunun-türkiye'de-benimsenmesi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batiyor" 1000  keyword_tr.txt
