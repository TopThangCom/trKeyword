java -jar getLatinTag.jar tr  "baxley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxseliyev" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxseliyeva" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baxseliyevin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bay" 1000  keyword_tr.txt
