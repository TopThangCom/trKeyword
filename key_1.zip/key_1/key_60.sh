java -jar getLatinTag.jar tr  "bakanlığı+mısır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığı'ndan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlığından" 1000  keyword_tr.txt
