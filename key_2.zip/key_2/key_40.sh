java -jar getLatinTag.jar tr  "balışeyh" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkabağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkabağında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balkabaklı" 1000  keyword_tr.txt
