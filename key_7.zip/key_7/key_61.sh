java -jar getLatinTag.jar tr  "başyapit" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyapı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyapıt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyapıtlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyapıtları" 1000  keyword_tr.txt
