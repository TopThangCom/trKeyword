java -jar getLatinTag.jar tr  "başlamıştır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanacaktır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlanan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslandi" 1000  keyword_tr.txt
