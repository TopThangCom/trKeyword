java -jar getLatinTag.jar tr  "bankacılıktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalararası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalardaki" 1000  keyword_tr.txt
