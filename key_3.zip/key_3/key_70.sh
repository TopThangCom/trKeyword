java -jar getLatinTag.jar tr  "bankline" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankmobile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banknotları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banknotlarla" 1000  keyword_tr.txt
