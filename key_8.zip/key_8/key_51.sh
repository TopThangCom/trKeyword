java -jar getLatinTag.jar tr  "batırman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batışehir" 1000  keyword_tr.txt
