java -jar getLatinTag.jar tr  "bankalardan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankaların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankalarına" 1000  keyword_tr.txt
