java -jar getLatinTag.jar tr  "balikligol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balikyolu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balilla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balim" 1000  keyword_tr.txt
