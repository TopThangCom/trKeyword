java -jar getLatinTag.jar tr  "bahçesi'ne" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçesinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçetepe" 1000  keyword_tr.txt
