java -jar getLatinTag.jar tr  "baş-çene" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçetinçelik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçiftlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçiftlikte" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçı" 1000  keyword_tr.txt
