java -jar getLatinTag.jar tr  "başıbüyük" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıbüyük'te" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başıbüyükte" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıc" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basıcı" 1000  keyword_tr.txt
