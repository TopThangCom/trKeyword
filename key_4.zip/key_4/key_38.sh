java -jar getLatinTag.jar tr  "basamakli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklıya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklıyı" 1000  keyword_tr.txt
