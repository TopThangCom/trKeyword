java -jar getLatinTag.jar tr  "başvurularina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuruları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurularım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurularıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurularımı" 1000  keyword_tr.txt
