java -jar getLatinTag.jar tr  "baharatında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatlari" 1000  keyword_tr.txt
