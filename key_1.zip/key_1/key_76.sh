java -jar getLatinTag.jar tr  "bakaç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakacağım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakacağın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakacağız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakacakkadı" 1000  keyword_tr.txt
