java -jar getLatinTag.jar tr  "batağından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataklığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataklığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataklık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataklıklarda" 1000  keyword_tr.txt
