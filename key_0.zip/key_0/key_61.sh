java -jar getLatinTag.jar tr  "bağlanırım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanırken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanırsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanıyorsun" 1000  keyword_tr.txt
