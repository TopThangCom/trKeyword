java -jar getLatinTag.jar tr  "başdanışmanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdanışmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdanışmanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdemir" 1000  keyword_tr.txt
