java -jar getLatinTag.jar tr  "bakanımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanı'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanının" 1000  keyword_tr.txt
