java -jar getLatinTag.jar tr  "bakılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılırsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılıyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakılması" 1000  keyword_tr.txt
