java -jar getLatinTag.jar tr  "baskını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınının" 1000  keyword_tr.txt
