java -jar getLatinTag.jar tr  "baskıcım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılamak" 1000  keyword_tr.txt
