java -jar getLatinTag.jar tr  "bandrollü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandrolsüz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandrolü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baner" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baneva" 1000  keyword_tr.txt
