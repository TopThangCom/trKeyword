java -jar getLatinTag.jar tr  "bakiye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyeler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyeli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyemi" 1000  keyword_tr.txt
