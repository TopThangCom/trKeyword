java -jar getLatinTag.jar tr  "bahçemden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeme" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçemi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçemin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahcemsin" 1000  keyword_tr.txt
