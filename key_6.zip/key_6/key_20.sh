java -jar getLatinTag.jar tr  "başlatılamıyor." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılana" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatıldı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatılır" 1000  keyword_tr.txt
