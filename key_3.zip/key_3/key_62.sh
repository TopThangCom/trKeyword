java -jar getLatinTag.jar tr  "banlama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlandı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlanır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlanma" 1000  keyword_tr.txt
