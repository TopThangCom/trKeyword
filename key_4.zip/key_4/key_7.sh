java -jar getLatinTag.jar tr  "barolar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-on" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar-one" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baroniçe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baronlar" 1000  keyword_tr.txt
