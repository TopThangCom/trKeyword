java -jar getLatinTag.jar tr  "başlıklarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıksız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıkta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlılar" 1000  keyword_tr.txt
