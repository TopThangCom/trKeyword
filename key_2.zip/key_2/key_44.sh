java -jar getLatinTag.jar tr  "baklalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklava" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavacı" 1000  keyword_tr.txt
