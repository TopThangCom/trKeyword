java -jar getLatinTag.jar tr  "bazi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi-" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "@bazi_bazan.apk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi_beepmusic.org" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazibz" 1000  keyword_tr.txt
