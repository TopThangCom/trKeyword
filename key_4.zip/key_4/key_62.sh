java -jar getLatinTag.jar tr  "barının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışa" 1000  keyword_tr.txt
