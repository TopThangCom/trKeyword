java -jar getLatinTag.jar tr  "bayrağında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağınla" 1000  keyword_tr.txt
