java -jar getLatinTag.jar tr  "balığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balığını" 1000  keyword_tr.txt
