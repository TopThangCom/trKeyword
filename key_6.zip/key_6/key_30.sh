java -jar getLatinTag.jar tr  "başkentinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentlik" 1000  keyword_tr.txt
