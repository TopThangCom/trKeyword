java -jar getLatinTag.jar tr  "başkişi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkişisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskisiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskı)" 1000  keyword_tr.txt
