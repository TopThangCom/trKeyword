java -jar getLatinTag.jar tr  "bebek.y" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.yikama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.zibinlari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.zıbın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeler" 1000  keyword_tr.txt
