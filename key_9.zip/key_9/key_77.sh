java -jar getLatinTag.jar tr  "bazinfandel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazing" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazinis" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazink" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazinsky" 1000  keyword_tr.txt
