java -jar getLatinTag.jar tr  "bayezweni" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayfair" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayfield" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayginlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baygın" 1000  keyword_tr.txt
