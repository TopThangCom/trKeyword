java -jar getLatinTag.jar tr  "bakinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakioğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakir-" 1000  keyword_tr.txt
