java -jar getLatinTag.jar tr  "barsaye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsbay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsbüttel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barse" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barsel" 1000  keyword_tr.txt
