java -jar getLatinTag.jar tr  "bayraklarımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraklarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakli" 1000  keyword_tr.txt
