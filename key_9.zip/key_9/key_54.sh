java -jar getLatinTag.jar tr  "bayramında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramınız" 1000  keyword_tr.txt
