java -jar getLatinTag.jar tr  "becer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becerdik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceremedik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceremez" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceremiyorum" 1000  keyword_tr.txt
