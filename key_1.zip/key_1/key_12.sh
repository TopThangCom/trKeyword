java -jar getLatinTag.jar tr  "bakarsan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarsınız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakayım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakcel" 1000  keyword_tr.txt
