java -jar getLatinTag.jar tr  "bclk" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bclkt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bcm" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bcnet.biz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b-day" 1000  keyword_tr.txt
