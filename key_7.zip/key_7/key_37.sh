java -jar getLatinTag.jar tr  "batıniliğin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batınilik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batın-ı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batı'nın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batının" 1000  keyword_tr.txt
