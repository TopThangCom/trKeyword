java -jar getLatinTag.jar tr  "baselini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baselland" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basenem" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baseni" 1000  keyword_tr.txt
