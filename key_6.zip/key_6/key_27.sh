java -jar getLatinTag.jar tr  "başliği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başliklari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslikli" 1000  keyword_tr.txt
