java -jar getLatinTag.jar tr  "bağırmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmakla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmalık" 1000  keyword_tr.txt
