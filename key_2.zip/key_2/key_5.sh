java -jar getLatinTag.jar tr  "bakliyat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakliyatta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmakla" 1000  keyword_tr.txt
