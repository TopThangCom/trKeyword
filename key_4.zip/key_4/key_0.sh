java -jar getLatinTag.jar tr  "bar_xfer_buf_size" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bar.yard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baryl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baryonen" 1000  keyword_tr.txt
