java -jar getLatinTag.jar tr  "başarımları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarımlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarınet" 1000  keyword_tr.txt
