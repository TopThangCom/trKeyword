java -jar getLatinTag.jar tr  "baklavalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavalık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavalık-yufkadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavanin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baklavanın" 1000  keyword_tr.txt
