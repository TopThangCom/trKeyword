java -jar getLatinTag.jar tr  "başkalarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalarıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalaşım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkalaşımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldiri" 1000  keyword_tr.txt
