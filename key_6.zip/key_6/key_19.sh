java -jar getLatinTag.jar tr  "başlardım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarına" 1000  keyword_tr.txt
