java -jar getLatinTag.jar tr  "başrolleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başrolü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başrolün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başrolünde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başrolündesiniz" 1000  keyword_tr.txt
