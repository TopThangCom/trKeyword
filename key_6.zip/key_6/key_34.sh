java -jar getLatinTag.jar tr  "baskılamalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılanıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılanması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılanmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskılar" 1000  keyword_tr.txt
