java -jar getLatinTag.jar tr  "bakim.ayligi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakim.az" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakimektebleri" 1000  keyword_tr.txt
