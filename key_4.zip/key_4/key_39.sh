java -jar getLatinTag.jar tr  "basamaklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamakları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamaklarında" 1000  keyword_tr.txt
