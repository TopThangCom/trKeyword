java -jar getLatinTag.jar tr  "bandıra" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandıralı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırma/balıkesir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırma-bursa-ayazma" 1000  keyword_tr.txt
