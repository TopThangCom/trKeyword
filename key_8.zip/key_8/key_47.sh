java -jar getLatinTag.jar tr  "bayılıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılırsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılıyorum" 1000  keyword_tr.txt
