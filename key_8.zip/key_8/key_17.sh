java -jar getLatinTag.jar tr  "bayanzurkh" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayanzürkh" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayardelle" 1000  keyword_tr.txt
