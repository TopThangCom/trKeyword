java -jar getLatinTag.jar tr  "bankisole" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bank'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankları" 1000  keyword_tr.txt
