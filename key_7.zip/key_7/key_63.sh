java -jar getLatinTag.jar tr  "başlıyorsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyorsun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıyoruz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmaci" 1000  keyword_tr.txt
