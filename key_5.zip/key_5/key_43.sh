java -jar getLatinTag.jar tr  "başbantlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbaşa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbelası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başbereket" 1000  keyword_tr.txt
