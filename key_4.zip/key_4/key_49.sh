java -jar getLatinTag.jar tr  "barışma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışmam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışmaq" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışması" 1000  keyword_tr.txt
