java -jar getLatinTag.jar tr  "baldams" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldassari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balde" 1000  keyword_tr.txt
