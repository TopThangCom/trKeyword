java -jar getLatinTag.jar tr  "bankacilikta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacıların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankacılığı" 1000  keyword_tr.txt
