java -jar getLatinTag.jar tr  "banasın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banayi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banbif" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banbury" 1000  keyword_tr.txt
