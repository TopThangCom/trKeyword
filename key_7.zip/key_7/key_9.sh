java -jar getLatinTag.jar tr  "başyazıcıoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyiğit" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basyolla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batacağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batağa" 1000  keyword_tr.txt
