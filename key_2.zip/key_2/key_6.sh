java -jar getLatinTag.jar tr  "baktır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktıranlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktırdım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baktırmak" 1000  keyword_tr.txt
