java -jar getLatinTag.jar tr  "başarısızlıkla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlıklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısızlıktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarısoft" 1000  keyword_tr.txt
