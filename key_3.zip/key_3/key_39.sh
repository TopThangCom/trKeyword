java -jar getLatinTag.jar tr  "bandel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandele" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banderas" 1000  keyword_tr.txt
