java -jar getLatinTag.jar tr  "baskıvar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başko" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkök" 1000  keyword_tr.txt
