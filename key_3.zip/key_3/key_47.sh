java -jar getLatinTag.jar tr  "baltacılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balta&kürek&bıçak&testere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltalimanı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltalimanında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltalı" 1000  keyword_tr.txt
