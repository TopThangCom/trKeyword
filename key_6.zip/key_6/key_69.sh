java -jar getLatinTag.jar tr  "başlayacağını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baslayacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayacaktık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayacaktır" 1000  keyword_tr.txt
