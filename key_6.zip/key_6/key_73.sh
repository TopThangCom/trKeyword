java -jar getLatinTag.jar tr  "başkanlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskanligi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanliği" 1000  keyword_tr.txt
