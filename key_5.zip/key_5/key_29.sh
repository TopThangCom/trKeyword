java -jar getLatinTag.jar tr  "basılmasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başım" 1000  keyword_tr.txt
