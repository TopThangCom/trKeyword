java -jar getLatinTag.jar tr  "barbie'ye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbie'yi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbilere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbiye" 1000  keyword_tr.txt
