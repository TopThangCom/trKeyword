java -jar getLatinTag.jar tr  "başmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmakalıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmakçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmakinist" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmakta" 1000  keyword_tr.txt
