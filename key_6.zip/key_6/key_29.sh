java -jar getLatinTag.jar tr  "baskenmütze" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkent" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkente" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkentgaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkenti" 1000  keyword_tr.txt
