java -jar getLatinTag.jar tr  "bazic" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazid" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazîd" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazide" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazidi" 1000  keyword_tr.txt
