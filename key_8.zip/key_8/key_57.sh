java -jar getLatinTag.jar tr  "bayındırlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayıra" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayırakçaşehir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayırda" 1000  keyword_tr.txt
