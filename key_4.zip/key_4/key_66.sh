java -jar getLatinTag.jar tr  "barizi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(barı)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barıç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barım" 1000  keyword_tr.txt
