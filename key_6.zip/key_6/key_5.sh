java -jar getLatinTag.jar tr  "başkasinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskasiyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkasın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(başkasına" 1000  keyword_tr.txt
