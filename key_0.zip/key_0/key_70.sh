java -jar getLatinTag.jar tr  "bağlantılarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantılarınızı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bağlantılı)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantımız" 1000  keyword_tr.txt
