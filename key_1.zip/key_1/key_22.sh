java -jar getLatinTag.jar tr  "baildon" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bailen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bailer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bailey" 1000  keyword_tr.txt
