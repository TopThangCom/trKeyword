java -jar getLatinTag.jar tr  "bağlamazsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlaminda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamına" 1000  keyword_tr.txt
