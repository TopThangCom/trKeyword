java -jar getLatinTag.jar tr  "balıklarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklı" 1000  keyword_tr.txt
