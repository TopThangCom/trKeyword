java -jar getLatinTag.jar tr  "bazan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazanci" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazaraki" 1000  keyword_tr.txt
