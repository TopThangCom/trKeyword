java -jar getLatinTag.jar tr  "bazaze" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baze" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazel" 1000  keyword_tr.txt
