java -jar getLatinTag.jar tr  "bazikhar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baziki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilah" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazilari" 1000  keyword_tr.txt
