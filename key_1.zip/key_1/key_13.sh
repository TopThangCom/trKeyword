java -jar getLatinTag.jar tr  "bakanoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakardı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarız" 1000  keyword_tr.txt
