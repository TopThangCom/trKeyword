java -jar getLatinTag.jar tr  "bayrampaşa'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrampaşa-istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrampaşa/istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrampaşa/istanbul/türkiye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramsa" 1000  keyword_tr.txt
