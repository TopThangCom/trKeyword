java -jar getLatinTag.jar tr  "bayramtepe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramtepede" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramyeri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraq" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayraqda" 1000  keyword_tr.txt
