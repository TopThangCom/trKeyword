java -jar getLatinTag.jar tr  "basketbolun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolunda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketzg" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baski-boya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskil" 1000  keyword_tr.txt
