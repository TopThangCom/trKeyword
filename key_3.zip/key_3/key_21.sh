java -jar getLatinTag.jar tr  "balsarı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baltacı" 1000  keyword_tr.txt
