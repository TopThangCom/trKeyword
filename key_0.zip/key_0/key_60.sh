java -jar getLatinTag.jar tr  "bağlaraltı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarbaşi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bağlarbaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarbaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlarbaşına" 1000  keyword_tr.txt
