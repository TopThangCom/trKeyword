java -jar getLatinTag.jar tr  "barbasol" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbazu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "'bar'(bear)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbekü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barben" 1000  keyword_tr.txt
