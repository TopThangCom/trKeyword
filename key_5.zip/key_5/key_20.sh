java -jar getLatinTag.jar tr  "başından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başındayım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başındayken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başındaymışım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınevleri" 1000  keyword_tr.txt
