java -jar getLatinTag.jar tr  "balıkesir-çanakkale" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkesir'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkesirde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkesir'den" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkesirden" 1000  keyword_tr.txt
