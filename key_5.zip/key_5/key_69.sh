java -jar getLatinTag.jar tr  "başarisiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarisizlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basariya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başariyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarı" 1000  keyword_tr.txt
