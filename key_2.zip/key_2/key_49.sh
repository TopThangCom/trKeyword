java -jar getLatinTag.jar tr  "balevav" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balgamı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balgamlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baliç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balicek" 1000  keyword_tr.txt
