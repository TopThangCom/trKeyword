java -jar getLatinTag.jar tr  "başmüdür" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmüdürlüğü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmüdürlük" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmüdürü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmüfettiş" 1000  keyword_tr.txt
