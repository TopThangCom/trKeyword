java -jar getLatinTag.jar tr  "bakirçay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakire" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakirelerde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakireliğin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakirelik" 1000  keyword_tr.txt
