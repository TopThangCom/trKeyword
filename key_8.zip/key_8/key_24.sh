java -jar getLatinTag.jar tr  "batıyoruz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batkın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batma" 1000  keyword_tr.txt
