java -jar getLatinTag.jar tr  "basins" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basinski" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basîr" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basira" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basîrun" 1000  keyword_tr.txt
