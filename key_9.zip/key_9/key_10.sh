java -jar getLatinTag.jar tr  "bayramoglu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramoğulları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramören" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrampaşa" 1000  keyword_tr.txt
