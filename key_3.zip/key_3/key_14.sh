java -jar getLatinTag.jar tr  "ballıbaba" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıdağ" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıdere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballık" 1000  keyword_tr.txt
