java -jar getLatinTag.jar tr  "(bakiye/takas)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyeye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakiyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakı" 1000  keyword_tr.txt
