java -jar getLatinTag.jar tr  "balinaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balinaların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balinanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balinası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balinasının" 1000  keyword_tr.txt
