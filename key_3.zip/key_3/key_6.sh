java -jar getLatinTag.jar tr  "bandırmalıoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırmalıoğlunu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandırmaspor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandolera" 1000  keyword_tr.txt
