java -jar getLatinTag.jar tr  "battaniyesini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyesinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battığını" 1000  keyword_tr.txt
