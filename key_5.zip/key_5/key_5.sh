java -jar getLatinTag.jar tr  "başarılarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılısın" 1000  keyword_tr.txt
