java -jar getLatinTag.jar tr  "bamteli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamyanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamyası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bamyum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banaiye" 1000  keyword_tr.txt
