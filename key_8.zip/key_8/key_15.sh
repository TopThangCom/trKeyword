java -jar getLatinTag.jar tr  "baykar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykonur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baykurt" 1000  keyword_tr.txt
