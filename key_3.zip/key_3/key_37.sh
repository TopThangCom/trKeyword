java -jar getLatinTag.jar tr  "banli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlist" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banliyo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banliyö" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banlı" 1000  keyword_tr.txt
