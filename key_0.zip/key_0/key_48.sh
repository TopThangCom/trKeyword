java -jar getLatinTag.jar tr  "bağlanmiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmışım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanmıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlansın" 1000  keyword_tr.txt
