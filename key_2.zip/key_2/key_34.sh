java -jar getLatinTag.jar tr  "balastı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balastlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balastsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balataların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatalı" 1000  keyword_tr.txt
