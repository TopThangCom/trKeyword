java -jar getLatinTag.jar tr  "basmasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmasından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmasını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmayın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmayınız" 1000  keyword_tr.txt
