java -jar getLatinTag.jar tr  "bardağından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağı-şeffaf" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardahl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardak" 1000  keyword_tr.txt
