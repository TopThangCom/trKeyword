java -jar getLatinTag.jar tr  "başlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıklar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıklarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlıklarındaki" 1000  keyword_tr.txt
