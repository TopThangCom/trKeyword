java -jar getLatinTag.jar tr  "başyardımcılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyardımcısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyardımcısının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyayla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başyazıcı" 1000  keyword_tr.txt
