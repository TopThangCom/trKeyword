java -jar getLatinTag.jar tr  "basınçlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınçları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınçlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınçsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınçta" 1000  keyword_tr.txt
