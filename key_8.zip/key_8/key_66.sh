java -jar getLatinTag.jar tr  "bayılma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayılmış" 1000  keyword_tr.txt
