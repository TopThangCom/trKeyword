java -jar getLatinTag.jar tr  "bahsettiğim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsettim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahşire" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahşiş" 1000  keyword_tr.txt
