java -jar getLatinTag.jar tr  "bazılarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazılarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazılarının." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazılika" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazılıka" 1000  keyword_tr.txt
