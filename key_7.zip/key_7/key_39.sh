java -jar getLatinTag.jar tr  "bastı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastığın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastık" 1000  keyword_tr.txt
