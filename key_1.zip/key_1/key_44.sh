java -jar getLatinTag.jar tr  "bakarken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarmış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakarsam" 1000  keyword_tr.txt
