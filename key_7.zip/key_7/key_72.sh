java -jar getLatinTag.jar tr  "başvuruya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuruyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuruyor." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuruyu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başy" 1000  keyword_tr.txt
