java -jar getLatinTag.jar tr  "başladi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basladimi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladığımda" 1000  keyword_tr.txt
