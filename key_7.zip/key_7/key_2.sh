java -jar getLatinTag.jar tr  "başsoy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştabya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(baştaci" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştaci" 1000  keyword_tr.txt
