java -jar getLatinTag.jar tr  "batışehir'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batışı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batısında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batısındaki" 1000  keyword_tr.txt
