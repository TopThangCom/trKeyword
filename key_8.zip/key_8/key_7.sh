java -jar getLatinTag.jar tr  "bayrağımızdaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağımızdakı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrağına" 1000  keyword_tr.txt
