java -jar getLatinTag.jar tr  "batırdım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırel" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batırılmış" 1000  keyword_tr.txt
