java -jar getLatinTag.jar tr  "baharmı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar_oktay" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahar.öztan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharsın" 1000  keyword_tr.txt
