java -jar getLatinTag.jar tr  "başvurulur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurun" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurunuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurup" 1000  keyword_tr.txt
