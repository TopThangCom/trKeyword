java -jar getLatinTag.jar tr  "bakırın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bakırköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırköy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırköy/bakırköy/istanbul" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakırköy'de" 1000  keyword_tr.txt
