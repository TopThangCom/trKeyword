java -jar getLatinTag.jar tr  "baştürkmen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başucu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başucumda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başucuna" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başucunda" 1000  keyword_tr.txt
