java -jar getLatinTag.jar tr  "bebişler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becayiş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bece" 1000  keyword_tr.txt
