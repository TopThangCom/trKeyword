java -jar getLatinTag.jar tr  "bataryasız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bataryayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bateristleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batgirl" 1000  keyword_tr.txt
