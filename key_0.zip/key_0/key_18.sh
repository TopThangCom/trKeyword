java -jar getLatinTag.jar tr  "bağırmamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırmayan" 1000  keyword_tr.txt
