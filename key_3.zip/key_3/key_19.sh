java -jar getLatinTag.jar tr  "ballarat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balldin" 1000  keyword_tr.txt
