java -jar getLatinTag.jar tr  "bakterileri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterilerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterilerinin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterimi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakterinin" 1000  keyword_tr.txt
