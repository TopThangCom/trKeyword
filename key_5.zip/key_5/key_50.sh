java -jar getLatinTag.jar tr  "başımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımıza" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başımızdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basımları" 1000  keyword_tr.txt
