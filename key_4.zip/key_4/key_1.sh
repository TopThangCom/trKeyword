java -jar getLatinTag.jar tr  "bardot" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bards" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardsley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barduck" 1000  keyword_tr.txt
