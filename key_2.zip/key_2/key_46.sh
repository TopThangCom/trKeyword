java -jar getLatinTag.jar tr  "balıklara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklarda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıklarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkların" 1000  keyword_tr.txt
