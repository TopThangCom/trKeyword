java -jar getLatinTag.jar tr  "bayburt-" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayburtlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayburt'ta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayburt'taki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayburt'un" 1000  keyword_tr.txt
