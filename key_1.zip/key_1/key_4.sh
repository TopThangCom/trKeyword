java -jar getLatinTag.jar tr  "bahçıvanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baheri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahisklavuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahisler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahisleri" 1000  keyword_tr.txt
