java -jar getLatinTag.jar tr  "bebeklerim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerine" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeklerinin" 1000  keyword_tr.txt
