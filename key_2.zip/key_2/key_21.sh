java -jar getLatinTag.jar tr  "bakmasınlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmayacaksin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmayacaksın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakmayan" 1000  keyword_tr.txt
