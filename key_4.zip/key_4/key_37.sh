java -jar getLatinTag.jar tr  "barmenle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmenlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmera" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barmix" 1000  keyword_tr.txt
