java -jar getLatinTag.jar tr  "bagyurdu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağyurdu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağzı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağzıbağlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağzıları" 1000  keyword_tr.txt
