java -jar getLatinTag.jar tr  "bakım-onarım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımsız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımsızlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımyurdu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakın" 1000  keyword_tr.txt
