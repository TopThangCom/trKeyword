java -jar getLatinTag.jar tr  "başlatma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmada" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatmama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatması" 1000  keyword_tr.txt
