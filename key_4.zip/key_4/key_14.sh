java -jar getLatinTag.jar tr  "bardi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardic" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barding" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardisk" 1000  keyword_tr.txt
