java -jar getLatinTag.jar tr  "başkanının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanıyım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlar" 1000  keyword_tr.txt
