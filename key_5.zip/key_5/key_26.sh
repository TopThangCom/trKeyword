java -jar getLatinTag.jar tr  "based" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başefendi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeğmediler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeğmez" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başekin" 1000  keyword_tr.txt
