java -jar getLatinTag.jar tr  "başlatabilmek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatiyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlatıcı" 1000  keyword_tr.txt
