java -jar getLatinTag.jar tr  "başgör" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgötüren" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başgül" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başhane" 1000  keyword_tr.txt
