java -jar getLatinTag.jar tr  "be" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bearded" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bearizona" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bearman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beatmaker" 1000  keyword_tr.txt
