java -jar getLatinTag.jar tr  "bandanası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandariya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandazi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bande" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "banded" 1000  keyword_tr.txt
