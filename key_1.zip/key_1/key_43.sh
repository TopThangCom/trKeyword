java -jar getLatinTag.jar tr  "bahceleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeleriçi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelerinde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelerini" 1000  keyword_tr.txt
