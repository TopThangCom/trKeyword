java -jar getLatinTag.jar tr  "barın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınabilecekleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınağa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınağı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barınağına" 1000  keyword_tr.txt
