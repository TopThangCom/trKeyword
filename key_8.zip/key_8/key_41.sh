java -jar getLatinTag.jar tr  "bayilikler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilikleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilik-veren-giyim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilinir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayilmak" 1000  keyword_tr.txt
