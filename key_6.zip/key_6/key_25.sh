java -jar getLatinTag.jar tr  "başkaldıran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkaldırış" 1000  keyword_tr.txt
