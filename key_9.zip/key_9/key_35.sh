java -jar getLatinTag.jar tr  "bazlamaç" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlaması" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlarda" 1000  keyword_tr.txt
