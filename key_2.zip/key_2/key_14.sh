java -jar getLatinTag.jar tr  "baldırda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldırı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldırına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldırında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldırlar" 1000  keyword_tr.txt
