java -jar getLatinTag.jar tr  "bağlamında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamsal" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlana" 1000  keyword_tr.txt
