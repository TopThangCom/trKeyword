java -jar getLatinTag.jar tr  "başardım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarilar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarilari" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basarili" 1000  keyword_tr.txt
