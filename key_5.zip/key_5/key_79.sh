java -jar getLatinTag.jar tr  "başçıl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basçısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başçoban" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdaner" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başdanışman" 1000  keyword_tr.txt
