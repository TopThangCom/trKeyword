java -jar getLatinTag.jar tr  "balli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballin'" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballinamallard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballı" 1000  keyword_tr.txt
