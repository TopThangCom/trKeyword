java -jar getLatinTag.jar tr  "bayrağıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakdar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrakdizayn" 1000  keyword_tr.txt
