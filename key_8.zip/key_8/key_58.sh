java -jar getLatinTag.jar tr  "batısını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batısoke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batısöke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batı'ya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batıya" 1000  keyword_tr.txt
