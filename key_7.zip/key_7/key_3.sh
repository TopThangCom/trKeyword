java -jar getLatinTag.jar tr  "başvurdular" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basvurmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurmalıyım" 1000  keyword_tr.txt
