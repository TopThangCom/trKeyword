java -jar getLatinTag.jar tr  "baş." 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(başabaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başabaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basabilir" 1000  keyword_tr.txt
