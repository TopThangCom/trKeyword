java -jar getLatinTag.jar tr  "bazis-online.kz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazitak.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ba'zı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazıda" 1000  keyword_tr.txt
