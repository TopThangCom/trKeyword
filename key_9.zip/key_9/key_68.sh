java -jar getLatinTag.jar tr  "bayramdere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramdı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramdüğün" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayrami" 1000  keyword_tr.txt
