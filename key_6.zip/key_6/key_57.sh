java -jar getLatinTag.jar tr  "baskınları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınlarına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınlarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskınlığı" 1000  keyword_tr.txt
