java -jar getLatinTag.jar tr  "bardaklık)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaklıklı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardakta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaktaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaktan" 1000  keyword_tr.txt
