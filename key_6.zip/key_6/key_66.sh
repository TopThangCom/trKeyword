java -jar getLatinTag.jar tr  "basketbolcularımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolcusu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketboldaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basketbolu" 1000  keyword_tr.txt
