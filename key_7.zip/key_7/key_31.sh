java -jar getLatinTag.jar tr  "başvurur" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvururlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvururuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuru.seyhan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurusu" 1000  keyword_tr.txt
