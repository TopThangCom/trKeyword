java -jar getLatinTag.jar tr  "bahsayiş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsedebilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahseden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahseder" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsedicem" 1000  keyword_tr.txt
