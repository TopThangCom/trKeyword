java -jar getLatinTag.jar tr  "başlayanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayarak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlayıp" 1000  keyword_tr.txt
