java -jar getLatinTag.jar tr  "baharatçıbaşı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçılar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baharatçılarda" 1000  keyword_tr.txt
