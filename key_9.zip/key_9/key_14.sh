java -jar getLatinTag.jar tr  "bazillen" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazillus" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi.lrc" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi.lt" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazin" 1000  keyword_tr.txt
