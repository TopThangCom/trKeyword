java -jar getLatinTag.jar tr  "bastard" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baştaş" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastem" 1000  keyword_tr.txt
