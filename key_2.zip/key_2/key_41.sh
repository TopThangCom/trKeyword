java -jar getLatinTag.jar tr  "baküye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balabanağa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balabancık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balabey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balaca" 1000  keyword_tr.txt
