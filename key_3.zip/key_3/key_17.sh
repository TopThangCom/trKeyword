java -jar getLatinTag.jar tr  "ballıkaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıkayalar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballık/sandıklı/afyonkarahisar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballıkuyu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "ballı-meyveli" 1000  keyword_tr.txt
