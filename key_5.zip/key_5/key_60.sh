java -jar getLatinTag.jar tr  "başasistanlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basat'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basatın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başatlı" 1000  keyword_tr.txt
