java -jar getLatinTag.jar tr  "bahsedin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsediyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsediyorsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsediyorsak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahsediyorsunuz" 1000  keyword_tr.txt
