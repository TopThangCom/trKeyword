java -jar getLatinTag.jar tr  "bağkur'lu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkurlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkurlular" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağkuru" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağla" 1000  keyword_tr.txt
