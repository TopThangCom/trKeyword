java -jar getLatinTag.jar tr  "barajları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajlarımız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajlarımızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barajsız" 1000  keyword_tr.txt
