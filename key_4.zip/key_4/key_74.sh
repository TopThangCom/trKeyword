java -jar getLatinTag.jar tr  "başal" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başalan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basalım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başaltı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basamağa" 1000  keyword_tr.txt
