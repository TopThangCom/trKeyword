java -jar getLatinTag.jar tr  "basınçtan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başındaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başındakiler" 1000  keyword_tr.txt
