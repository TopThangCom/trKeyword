java -jar getLatinTag.jar tr  "barışıp" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışırız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barışlar" 1000  keyword_tr.txt
