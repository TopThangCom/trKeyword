java -jar getLatinTag.jar tr  "bakımaylığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımcı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımcısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakımdaki" 1000  keyword_tr.txt
