java -jar getLatinTag.jar tr  "başman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmaneden" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmane/izmir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basması" 1000  keyword_tr.txt
