java -jar getLatinTag.jar tr  "bakanla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakanlar.kurulu" 1000  keyword_tr.txt
