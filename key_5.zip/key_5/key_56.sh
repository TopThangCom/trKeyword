java -jar getLatinTag.jar tr  "basına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başınalık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başınayız" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basınç" 1000  keyword_tr.txt
