java -jar getLatinTag.jar tr  "başladığımızda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladığını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladıkları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladıktan" 1000  keyword_tr.txt
