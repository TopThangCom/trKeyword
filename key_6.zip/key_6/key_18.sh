java -jar getLatinTag.jar tr  "baslam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamadi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlamadı" 1000  keyword_tr.txt
