java -jar getLatinTag.jar tr  "bebekçe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekçilik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek'e" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebeke" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekevi" 1000  keyword_tr.txt
