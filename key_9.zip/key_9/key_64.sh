java -jar getLatinTag.jar tr  "bazaarturkey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza+başlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baza+başlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazal" 1000  keyword_tr.txt
