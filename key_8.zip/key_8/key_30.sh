java -jar getLatinTag.jar tr  "baydöner" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayed" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayelsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bayer)" 1000  keyword_tr.txt
