java -jar getLatinTag.jar tr  "bağırsaktan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırtma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağırtmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağış" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışçı" 1000  keyword_tr.txt
