java -jar getLatinTag.jar tr  "beceriklican" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriklihan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "becerikliler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriklilik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "beceriklinin" 1000  keyword_tr.txt
