java -jar getLatinTag.jar tr  "başlarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarınızı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlarıyla" 1000  keyword_tr.txt
