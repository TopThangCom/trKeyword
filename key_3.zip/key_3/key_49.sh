java -jar getLatinTag.jar tr  "bankanızdaki" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankanızla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası-" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası..." 1000  keyword_tr.txt
