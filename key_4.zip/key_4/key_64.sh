java -jar getLatinTag.jar tr  "bariyer" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyeri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyerini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bariyerler" 1000  keyword_tr.txt
