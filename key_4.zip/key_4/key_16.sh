java -jar getLatinTag.jar tr  "bardufos" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardugo" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardust" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardy" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardyor" 1000  keyword_tr.txt
