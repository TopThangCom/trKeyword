java -jar getLatinTag.jar tr  "başe" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "base.bin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basebuilder" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeczacı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başeczacının" 1000  keyword_tr.txt
