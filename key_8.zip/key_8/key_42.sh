java -jar getLatinTag.jar tr  "batşi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batsın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battalbey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "battaniyede" 1000  keyword_tr.txt
