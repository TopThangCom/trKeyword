java -jar getLatinTag.jar tr  "batmani" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmanin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batman'ın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmanın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmanlı" 1000  keyword_tr.txt
