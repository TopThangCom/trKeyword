java -jar getLatinTag.jar tr  "basaririz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarirlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başari-sat" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarisi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarisinda" 1000  keyword_tr.txt
