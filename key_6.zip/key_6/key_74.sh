java -jar getLatinTag.jar tr  "başkanlığı-nakil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığını" 1000  keyword_tr.txt
