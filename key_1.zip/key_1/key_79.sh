java -jar getLatinTag.jar tr  "bahcekoyde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeköy'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelerde" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelerden" 1000  keyword_tr.txt
