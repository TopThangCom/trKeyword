java -jar getLatinTag.jar tr  "bebeklik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.odasi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.odası" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebekoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bebek.omlet" 1000  keyword_tr.txt
