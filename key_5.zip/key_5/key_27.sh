java -jar getLatinTag.jar tr  "başarıda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıdan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarıdır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başarılar" 1000  keyword_tr.txt
