java -jar getLatinTag.jar tr  "başladım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başladıysa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başlak" 1000  keyword_tr.txt
