java -jar getLatinTag.jar tr  "başakar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakçı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakcığım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakıncı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başakla" 1000  keyword_tr.txt
