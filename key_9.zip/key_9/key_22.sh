java -jar getLatinTag.jar tr  "bazig" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazigar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazigaran" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazi.ir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazik" 1000  keyword_tr.txt
