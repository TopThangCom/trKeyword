java -jar getLatinTag.jar tr  "batmadan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmadı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmadığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmadımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmak" 1000  keyword_tr.txt
