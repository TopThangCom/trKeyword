java -jar getLatinTag.jar tr  "bayleaf.id" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayless" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayley" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayleys" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayliner" 1000  keyword_tr.txt
