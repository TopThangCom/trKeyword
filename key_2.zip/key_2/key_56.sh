java -jar getLatinTag.jar tr  "baldirlarin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(baldi’s" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldi's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baldıra" 1000  keyword_tr.txt
