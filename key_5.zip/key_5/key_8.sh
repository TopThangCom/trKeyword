java -jar getLatinTag.jar tr  "basılır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılışları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılmalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basılması" 1000  keyword_tr.txt
