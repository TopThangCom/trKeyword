java -jar getLatinTag.jar tr  "bakıcılı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcılığı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcısına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakıcısının" 1000  keyword_tr.txt
