java -jar getLatinTag.jar tr  "bakışlarında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışlım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakışmak" 1000  keyword_tr.txt
