java -jar getLatinTag.jar tr  "balıkçılık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçılıkta" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkçıoğlu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balıkcısı" 1000  keyword_tr.txt
