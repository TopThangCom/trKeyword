java -jar getLatinTag.jar tr  "bahtı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtıma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtımın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahtımız" 1000  keyword_tr.txt
