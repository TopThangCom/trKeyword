java -jar getLatinTag.jar tr  "başvurabileceğimiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurabilecek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurabilirim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvuramıyorum" 1000  keyword_tr.txt
