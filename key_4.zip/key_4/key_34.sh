java -jar getLatinTag.jar tr  "barkodlama" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodlar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkodumu" 1000  keyword_tr.txt
