java -jar getLatinTag.jar tr  "bayramlaşmayacak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlaştı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bayramlıklar" 1000  keyword_tr.txt
