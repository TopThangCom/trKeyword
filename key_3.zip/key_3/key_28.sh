java -jar getLatinTag.jar tr  "bankerleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankislam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankislam.biz" 1000  keyword_tr.txt
