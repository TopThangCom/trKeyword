java -jar getLatinTag.jar tr  "bağlamasıyla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamaya" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamayan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlamaz" 1000  keyword_tr.txt
