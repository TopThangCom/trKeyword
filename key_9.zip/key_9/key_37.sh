java -jar getLatinTag.jar tr  "bazzini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazzi's" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.bakim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "b.barker" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bbc.co.uk/iplayer" 1000  keyword_tr.txt
