java -jar getLatinTag.jar tr  "basenleri" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basenli" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basenliler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "basenlilere" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baş-er" 1000  keyword_tr.txt
