java -jar getLatinTag.jar tr  "bandı-" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandıcam" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandına" 1000  keyword_tr.txt
