java -jar getLatinTag.jar tr  "bandajları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandamiz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandanaları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandanalı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bandanalık" 1000  keyword_tr.txt
