java -jar getLatinTag.jar tr  "barla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlad" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barla'da" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlake" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barlami" 1000  keyword_tr.txt
