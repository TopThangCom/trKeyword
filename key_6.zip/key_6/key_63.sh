java -jar getLatinTag.jar tr  "baskına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıncı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskıncısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskındır" 1000  keyword_tr.txt
