java -jar getLatinTag.jar tr  "(bahçelievler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "(bahçelievler)" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelievler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelievler'de" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçelievlerde" 1000  keyword_tr.txt
