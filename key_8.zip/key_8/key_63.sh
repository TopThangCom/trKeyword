java -jar getLatinTag.jar tr  "batmıştır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmıyorsa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmobil" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batmobile" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "batn-ı" 1000  keyword_tr.txt
