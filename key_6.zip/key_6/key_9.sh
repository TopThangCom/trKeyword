java -jar getLatinTag.jar tr  "baskilamak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskilar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskili" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskil'in" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkilise" 1000  keyword_tr.txt
