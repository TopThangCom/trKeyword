java -jar getLatinTag.jar tr  "barkal" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkala" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkarby" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkarmazyn.pl" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barkaya" 1000  keyword_tr.txt
