java -jar getLatinTag.jar tr  "bahçeye" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahceyi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçeyi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçivan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bahçivanlar" 1000  keyword_tr.txt
