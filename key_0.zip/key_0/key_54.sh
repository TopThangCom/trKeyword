java -jar getLatinTag.jar tr  "bağlanamaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglanamiyorum" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanamıyor" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanamıyorsunuz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlanamıyorum" 1000  keyword_tr.txt
