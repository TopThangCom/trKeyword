java -jar getLatinTag.jar tr  "bağışına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışında" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışından" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışını" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağışının" 1000  keyword_tr.txt
