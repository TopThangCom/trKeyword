java -jar getLatinTag.jar tr  "başvurusuna" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurusunda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurusundan" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurusunu" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başvurusunun" 1000  keyword_tr.txt
