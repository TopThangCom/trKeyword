java -jar getLatinTag.jar tr  "basmaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmelek" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmelekler" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmeleklerin" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başmeleklerle" 1000  keyword_tr.txt
