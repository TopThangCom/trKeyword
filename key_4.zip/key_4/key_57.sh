java -jar getLatinTag.jar tr  "bardacık" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardağa" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardagi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaği" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bardaginda" 1000  keyword_tr.txt
