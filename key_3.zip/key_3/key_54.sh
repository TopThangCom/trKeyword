java -jar getLatinTag.jar tr  "bar-bench" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberaz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barber-colman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberey" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberine" 1000  keyword_tr.txt
