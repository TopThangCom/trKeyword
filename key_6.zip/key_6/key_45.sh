java -jar getLatinTag.jar tr  "başkanliğina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskanlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlik" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkanlığa" 1000  keyword_tr.txt
