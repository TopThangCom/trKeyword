java -jar getLatinTag.jar tr  "bankası-kuruköprü" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankasımı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankasına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankası'nda" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bankasında" 1000  keyword_tr.txt
