java -jar getLatinTag.jar tr  "bastırınca" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırma" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırmak" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bastırması" 1000  keyword_tr.txt
