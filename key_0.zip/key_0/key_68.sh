java -jar getLatinTag.jar tr  "bağlıydı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıyı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıyım" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıyken" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlıyor" 1000  keyword_tr.txt
