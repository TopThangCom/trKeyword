java -jar getLatinTag.jar tr  "barberini" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberino" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberism" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barberka" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "barbermaskine" 1000  keyword_tr.txt
