java -jar getLatinTag.jar tr  "bağlantınızın" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baglantısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısına" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bağlantısında" 1000  keyword_tr.txt
