java -jar getLatinTag.jar tr  "başkadır" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkahraman" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "başkal" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskalarina" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "baskalarini" 1000  keyword_tr.txt
