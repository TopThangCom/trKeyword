java -jar getLatinTag.jar tr  "bakkallar" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkallara" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakkalları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakladan" 1000  keyword_tr.txt
