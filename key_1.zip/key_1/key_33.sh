java -jar getLatinTag.jar tr  "bakabilir" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakabilirim" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakabilirmi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakabilirsiniz" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bakabilmek" 1000  keyword_tr.txt
