java -jar getLatinTag.jar tr  "bazları" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazların" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlarının" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazlarla" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "bazli" 1000  keyword_tr.txt
