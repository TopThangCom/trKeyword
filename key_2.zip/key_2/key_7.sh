java -jar getLatinTag.jar tr  "balatonfüred" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balatonlelle" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balayi" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balayı" 1000  keyword_tr.txt
java -jar getLatinTag.jar tr  "balayına" 1000  keyword_tr.txt
